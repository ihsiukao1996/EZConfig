/*
  * @author STMicroelectronics MMY Application team
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under ST MIX_MYLIBERTY SOFTWARE LICENSE AGREEMENT (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/Mix_MyLiberty
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied,
  * AND SPECIFICALLY DISCLAIMING THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
*/

package com.st.st25nfc.generic;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.st.st25nfc.R;
import com.st.st25nfc.generic.util.BufferAnalyze;
import com.st.st25sdk.NFCTag;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

import static android.app.Activity.RESULT_OK;
import static com.st.st25nfc.generic.util.UIHelper.getFileName;

public class IotModbusFragment extends STFragment {


    public static IotModbusFragment newInstance(Context context) {
        IotModbusFragment f = new IotModbusFragment();
        /* If needed, pass some argument to the fragment
        Bundle args = new Bundle();
        args.putInt("index", index);
        f.setArguments(args);
        */

        // Set the title of this fragment
        //f.setTitle(context.getResources().getString(R.string.tag_info));
        f.setTitle("MQTT");

        return f;
    }

    public IotModbusFragment() {
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.fragment_iot_mqtt, container, false);
        mView = view;

        initView();
        return (View) view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private class FillViewTask extends STFragment.FillViewTask {



        EditText MQTT_Host;
        EditText MQTT_Client;
        EditText MQTT_PWD;
        EditText MQTT_Topic;
        EditText MQTT_Sub;
        EditText MQTT_Port;
        EditText MQTT_Ver;
        EditText MQTT_Live;
        //Spinner Interrupt_spinner;
        Spinner MQTTQoS_spinner;
        Spinner MQTTRetain_spinner;
        CheckBox checkBox_owInterrupt;
        CheckBox checkBox_inputInterrupt;
        CheckBox checkBox_ctInterrupt;
        CheckBox checkBox_acInterrupt;
        CheckBox checkBox_ssl;
        CheckBox checkBox_sni;
        CheckBox checkBox_Client_Key;
        CheckBox checkBox_ca;
        CheckBox checkBox_UserKey_Cert;
        Button button_ca;
        Button button_Client_Key;
        Button button_UserKey_Cert;
        //EditText SSL_Version;
        //EditText Security_Level;

        Spinner SSL_Version_spinner;
        Spinner Security_Level_spinner;

        public FillViewTask() {
        }

        @Override
        protected Integer doInBackground(NFCTag... param) {


            return 0;
        }


        @Override
        protected void onPostExecute(Integer result) {
            System.out.println("onPostExecute-1()");
            if (result == 0) {
                if (mView != null) {
                    getActivity().runOnUiThread (new Thread(new Runnable() {
                        public void run() {

                            //SSL_Version = (EditText) mView.findViewById(R.id.SSL_Version);
                            //Security_Level = (EditText) mView.findViewById(R.id.Security_Level);

                            //SSL_Version.setText(BufferAnalyze.SSL_Version_edit);
                            //Security_Level.setText(BufferAnalyze.Security_Level_edit);

                            SSL_Version_spinner = (Spinner) mView.findViewById(R.id.SSL_Version_spinner);
                            SpinAdapter2 SSL_Version_adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option10);//simple_spinner_item 版面配置是由平台提供
                            SSL_Version_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            SSL_Version_spinner.setAdapter(SSL_Version_adapter);
                            SSL_Version_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    Log.d("IOT","選擇:");
                                    BufferAnalyze.SSL_Version_edit = ""+position;
                                    BufferAnalyze.edit_mBuffer[1195] = (""+position).toString().trim().getBytes(StandardCharsets.US_ASCII)[0];

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            try {
                                SSL_Version_spinner.setSelection(Integer.parseInt(BufferAnalyze.SSL_Version_edit));
                            }
                            catch (Exception e){
                                SSL_Version_spinner.setSelection(0);
                            }



                            Security_Level_spinner = (Spinner) mView.findViewById(R.id.Security_Level_spinner);
                            SpinAdapter2 Security_Level_adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option11);//simple_spinner_item 版面配置是由平台提供
                            Security_Level_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            Security_Level_spinner.setAdapter(Security_Level_adapter);
                            Security_Level_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    Log.d("IOT","選擇:");
                                    BufferAnalyze.Security_Level_edit = ""+position;
                                    BufferAnalyze.edit_mBuffer[1196] = (""+position).toString().trim().getBytes(StandardCharsets.US_ASCII)[0];

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            try {
                                Security_Level_spinner.setSelection(Integer.parseInt(BufferAnalyze.Security_Level_edit));
                            }
                            catch (Exception e){
                                Security_Level_spinner.setSelection(0);
                            }

                            checkBox_ssl = (CheckBox) mView.findViewById(R.id.checkBox_ssl);
                            checkBox_ssl.setChecked((BufferAnalyze.SSL_edit==0)?false:true);
                            checkBox_ssl.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                    // TODO Auto-generated method stub
                                    if(isChecked==true){
                                        BufferAnalyze.SSL_edit=1;
                                        BufferAnalyze.edit_mBuffer[1193] |= 0x80;
                                    }
                                    else{
                                        BufferAnalyze.SSL_edit=0;
                                        BufferAnalyze.edit_mBuffer[1193] &= ~0x80;
                                    }
                                }
                            });


                            checkBox_sni = (CheckBox) mView.findViewById(R.id.checkBox_sni);
                            checkBox_sni.setChecked((BufferAnalyze.SNI_edit==0)?false:true);
                            checkBox_sni.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                    // TODO Auto-generated method stub
                                    if(isChecked==true){
                                        BufferAnalyze.SNI_edit=1;
                                        BufferAnalyze.edit_mBuffer[1193] |= 0x40;
                                    }
                                    else{
                                        BufferAnalyze.SNI_edit=0;
                                        BufferAnalyze.edit_mBuffer[1193] &= ~0x40;
                                    }
                                }
                            });

                            checkBox_Client_Key = (CheckBox) mView.findViewById(R.id.checkBox_Client_Key);
                            checkBox_Client_Key.setChecked((BufferAnalyze.ClientKey_Cert_edit==0)?false:true);
                            checkBox_Client_Key.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                    // TODO Auto-generated method stub
                                    if(isChecked==true){
                                        BufferAnalyze.ClientKey_Cert_edit=1;
                                        BufferAnalyze.edit_mBuffer[1193] |= 0x10;
                                    }
                                    else{
                                        BufferAnalyze.ClientKey_Cert_edit=0;
                                        BufferAnalyze.edit_mBuffer[1193] &= ~0x10;
                                    }
                                }
                            });

                            checkBox_ca = (CheckBox) mView.findViewById(R.id.checkBox_ca);
                            checkBox_ca.setChecked((BufferAnalyze.CA_Certification_edit==0)?false:true);
                            checkBox_ca.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                    // TODO Auto-generated method stub
                                    if(isChecked==true){
                                        BufferAnalyze.CA_Certification_edit=1;
                                        BufferAnalyze.edit_mBuffer[1193] |= 0x20;
                                    }
                                    else{
                                        BufferAnalyze.CA_Certification_edit=0;
                                        BufferAnalyze.edit_mBuffer[1193] &= ~0x20;
                                    }
                                }
                            });


                            checkBox_UserKey_Cert = (CheckBox) mView.findViewById(R.id.checkBox_UserKey_Cert);
                            checkBox_UserKey_Cert.setChecked((BufferAnalyze.UserKey_Cert_edit==0)?false:true);
                            checkBox_UserKey_Cert.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                    // TODO Auto-generated method stub
                                    if(isChecked==true){
                                        BufferAnalyze.UserKey_Cert_edit=1;
                                        BufferAnalyze.edit_mBuffer[1193] |= 0x08;
                                    }
                                    else{
                                        BufferAnalyze.UserKey_Cert_edit=0;
                                        BufferAnalyze.edit_mBuffer[1193] &= ~0x08;
                                    }
                                }
                            });


                            button_ca = (Button) mView.findViewById(R.id.button_ca);
                            button_ca.setOnClickListener(new View.OnClickListener() {

                                public void onClick(View v) {
                                    // TODO Auto-generated method stub
                                    if(checkBox_ca.isChecked()==true){

                                        String message = getString(R.string.select_a_file);

                                        Intent intent = new Intent()
                                                .setType("*/*")
                                                .setAction(Intent.ACTION_GET_CONTENT);

                                        // Special intent for Samsung file manager
                                        Intent sIntent = new Intent("com.sec.android.app.myfiles.PICK_DATA");
                                        sIntent.addCategory(Intent.CATEGORY_DEFAULT);

                                        Intent chooserIntent;
                                        if (mView.getContext().getPackageManager().resolveActivity(sIntent, 0) != null){
                                            // it is device with samsung file manager
                                            chooserIntent = Intent.createChooser(sIntent, message);
                                            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] { intent});
                                        }
                                        else {
                                            chooserIntent = Intent.createChooser(intent, message);
                                        }

                                        startActivityForResult(chooserIntent, 0);

                                    }
                                }
                            });

                            button_Client_Key = (Button) mView.findViewById(R.id.button_Client_Key);
                            button_Client_Key.setOnClickListener(new View.OnClickListener() {

                                public void onClick(View v) {
                                    // TODO Auto-generated method stub
                                    if(checkBox_Client_Key.isChecked()==true){

                                        String message = getString(R.string.select_a_file);

                                        Intent intent = new Intent()
                                                .setType("*/*")
                                                .setAction(Intent.ACTION_GET_CONTENT);

                                        // Special intent for Samsung file manager
                                        Intent sIntent = new Intent("com.sec.android.app.myfiles.PICK_DATA");
                                        sIntent.addCategory(Intent.CATEGORY_DEFAULT);

                                        Intent chooserIntent;
                                        if (mView.getContext().getPackageManager().resolveActivity(sIntent, 0) != null){
                                            // it is device with samsung file manager
                                            chooserIntent = Intent.createChooser(sIntent, message);
                                            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] { intent});
                                        }
                                        else {
                                            chooserIntent = Intent.createChooser(intent, message);
                                        }

                                        startActivityForResult(chooserIntent, 1);

                                    }
                                }
                            });

                            button_UserKey_Cert = (Button) mView.findViewById(R.id.button_UserKey_Cert);
                            button_UserKey_Cert.setOnClickListener(new View.OnClickListener() {

                                public void onClick(View v) {
                                    // TODO Auto-generated method stub
                                    if(checkBox_UserKey_Cert.isChecked()==true){

                                        String message = getString(R.string.select_a_file);

                                        Intent intent = new Intent()
                                                .setType("*/*")
                                                .setAction(Intent.ACTION_GET_CONTENT);

                                        // Special intent for Samsung file manager
                                        Intent sIntent = new Intent("com.sec.android.app.myfiles.PICK_DATA");
                                        sIntent.addCategory(Intent.CATEGORY_DEFAULT);

                                        Intent chooserIntent;
                                        if (mView.getContext().getPackageManager().resolveActivity(sIntent, 0) != null){
                                            // it is device with samsung file manager
                                            chooserIntent = Intent.createChooser(sIntent, message);
                                            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] { intent});
                                        }
                                        else {
                                            chooserIntent = Intent.createChooser(intent, message);
                                        }

                                        startActivityForResult(chooserIntent, 2);

                                    }
                                }
                            });



                            MQTT_Host = (EditText) mView.findViewById(R.id.MQTT_Host);
                            MQTT_Host.setText(BufferAnalyze.MQTTHost_edit);
                            MQTT_Host.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);

                                    for(int i=684;i<=783;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }

                                    for(int i=0;i<b.length;i++){
                                        BufferAnalyze.edit_mBuffer[684+i]=b[i];
                                    }

                                    BufferAnalyze.MQTTHost_edit = s;

                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });

                            MQTT_Client = (EditText) mView.findViewById(R.id.MQTT_Client);
                            MQTT_Client.setText(BufferAnalyze.MQTTClient_edit);
                            MQTT_Client.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);

                                    for(int i=784;i<=808;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }

                                    for(int i=0;i<b.length;i++){
                                        BufferAnalyze.edit_mBuffer[784+i]=b[i];
                                    }

                                    BufferAnalyze.MQTTClient_edit = s;

                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });

                            MQTT_PWD = (EditText) mView.findViewById(R.id.MQTT_PWD);
                            MQTT_PWD.setText(BufferAnalyze.MQTTPwd_edit);
                            MQTT_PWD.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);

                                    for(int i=809;i<=853;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }

                                    for(int i=0;i<b.length;i++){
                                        BufferAnalyze.edit_mBuffer[809+i]=b[i];
                                    }

                                    BufferAnalyze.MQTTPwd_edit = s;

                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });

                            MQTT_Topic = (EditText) mView.findViewById(R.id.MQTT_Topic);
                            MQTT_Topic.setText(BufferAnalyze.MQTTTopic_edit);
                            MQTT_Topic.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);

                                    for(int i=854;i<=878;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }

                                    for(int i=0;i<b.length;i++){
                                        BufferAnalyze.edit_mBuffer[854+i]=b[i];
                                    }

                                    BufferAnalyze.MQTTTopic_edit = s;

                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });

                            MQTT_Sub = (EditText) mView.findViewById(R.id.MQTT_Sub);
                            MQTT_Sub.setText(BufferAnalyze.MQTTSub_edit);
                            MQTT_Sub.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);

                                    for(int i=879;i<=923;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }

                                    for(int i=0;i<b.length;i++){
                                        BufferAnalyze.edit_mBuffer[879+i]=b[i];
                                    }

                                    BufferAnalyze.MQTTSub_edit = s;

                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });

                            MQTT_Port = (EditText) mView.findViewById(R.id.MQTT_Port);
                            MQTT_Port.setText(BufferAnalyze.MQTTPort_edit);
                            MQTT_Port.setInputType(InputType.TYPE_CLASS_NUMBER);
                            MQTT_Port.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);
                                    for(int i=925;i<=929;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }
                                    if(b.length==1){
                                        BufferAnalyze.edit_mBuffer[925]=b[0];
                                        BufferAnalyze.edit_mBuffer[926]=0;
                                        BufferAnalyze.edit_mBuffer[927]=0;
                                        BufferAnalyze.edit_mBuffer[928]=0;
                                        BufferAnalyze.edit_mBuffer[929]=0;
                                    }
                                    else if(b.length==2){
                                        BufferAnalyze.edit_mBuffer[925]=b[0];
                                        BufferAnalyze.edit_mBuffer[926]=b[1];
                                        BufferAnalyze.edit_mBuffer[927]=0;
                                        BufferAnalyze.edit_mBuffer[928]=0;
                                        BufferAnalyze.edit_mBuffer[929]=0;
                                    }
                                    else if(b.length==3){
                                        BufferAnalyze.edit_mBuffer[925]=b[0];
                                        BufferAnalyze.edit_mBuffer[926]=b[1];
                                        BufferAnalyze.edit_mBuffer[927]=b[2];
                                        BufferAnalyze.edit_mBuffer[928]=0;
                                        BufferAnalyze.edit_mBuffer[929]=0;
                                    }
                                    else if(b.length==4){
                                        BufferAnalyze.edit_mBuffer[925]=b[0];
                                        BufferAnalyze.edit_mBuffer[926]=b[1];
                                        BufferAnalyze.edit_mBuffer[927]=b[2];
                                        BufferAnalyze.edit_mBuffer[928]=b[3];
                                        BufferAnalyze.edit_mBuffer[929]=0;
                                    }
                                    else if(b.length==5){
                                        int num = Integer.parseInt(cs.toString().trim());
                                        if(num>65536){
                                            MQTT_Port.setText("65536");
                                        }
                                        else{
                                            BufferAnalyze.edit_mBuffer[925]=b[0];
                                            BufferAnalyze.edit_mBuffer[926]=b[1];
                                            BufferAnalyze.edit_mBuffer[927]=b[2];
                                            BufferAnalyze.edit_mBuffer[928]=b[3];
                                            BufferAnalyze.edit_mBuffer[929]=b[4];
                                        }
                                    }
                                    BufferAnalyze.MQTTPort_edit = ""+MQTT_Port.getText();

                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });

                            MQTT_Ver = (EditText) mView.findViewById(R.id.MQTT_Ver);
                            MQTT_Ver.setText(BufferAnalyze.MQTTVer_edit);
                            MQTT_Ver.setInputType(InputType.TYPE_CLASS_NUMBER);
                            MQTT_Ver.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);

                                    for(int i=924;i<=924;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }
                                    if(b.length==1){
                                        int num = Integer.parseInt(cs.toString().trim());
                                        if(num>4){
                                            MQTT_Ver.setText("4");
                                        }
                                        else if(num < 3){
                                            MQTT_Ver.setText("3");
                                        }
                                        else{
                                            BufferAnalyze.edit_mBuffer[924]=b[0];
                                        }
                                    }

                                    BufferAnalyze.MQTTVer_edit = ""+MQTT_Ver.getText();

                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });

                            MQTT_Live = (EditText) mView.findViewById(R.id.MQTT_Live);
                            MQTT_Live.setText(BufferAnalyze.MQTTLive_edit);
                            MQTT_Live.setInputType(InputType.TYPE_CLASS_NUMBER);
                            MQTT_Live.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);

                                    for(int i=930;i<=933;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }
                                    if(b.length==1){
                                        BufferAnalyze.edit_mBuffer[930]=b[0];
                                        BufferAnalyze.edit_mBuffer[931]=0;
                                        BufferAnalyze.edit_mBuffer[932]=0;
                                        BufferAnalyze.edit_mBuffer[933]=0;
                                    }
                                    else if(b.length==2){
                                        BufferAnalyze.edit_mBuffer[930]=b[0];
                                        BufferAnalyze.edit_mBuffer[931]=b[1];
                                        BufferAnalyze.edit_mBuffer[932]=0;
                                        BufferAnalyze.edit_mBuffer[933]=0;
                                    }
                                    else if(b.length==3){
                                        BufferAnalyze.edit_mBuffer[930]=b[0];
                                        BufferAnalyze.edit_mBuffer[931]=b[1];
                                        BufferAnalyze.edit_mBuffer[932]=b[2];
                                        BufferAnalyze.edit_mBuffer[933]=0;
                                    }
                                    else if(b.length==4){
                                        int num = Integer.parseInt(cs.toString().trim());
                                        if(num>3600){
                                            MQTT_Live.setText("3600");
                                        }
                                        else{
                                            BufferAnalyze.edit_mBuffer[930]=b[0];
                                            BufferAnalyze.edit_mBuffer[931]=b[1];
                                            BufferAnalyze.edit_mBuffer[932]=b[2];
                                            BufferAnalyze.edit_mBuffer[933]=b[3];
                                        }

                                    }

                                    BufferAnalyze.MQTTLive_edit = ""+MQTT_Live.getText();

                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });
                            SpinAdapter2 adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option2);//simple_spinner_item 版面配置是由平台提供

                            /*
                            Interrupt_spinner = (Spinner) mView.findViewById(R.id.Interrupt_spinner);
                            SpinAdapter2 adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option2);//simple_spinner_item 版面配置是由平台提供
                            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            Interrupt_spinner.setAdapter(adapter);
                            Interrupt_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    Log.d("IOT","選擇:");
                                    if(position == 1) {
                                        BufferAnalyze.Interrupt_Flag_edit = (byte)255;
                                        BufferAnalyze.edit_mBuffer[936] = (byte)255;
                                    }
                                    else {
                                        BufferAnalyze.Interrupt_Flag_edit = (byte)position;
                                        BufferAnalyze.edit_mBuffer[936] = (byte)position;
                                    }

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            Interrupt_spinner.setSelection((BufferAnalyze.Interrupt_Flag_edit)>1?0:BufferAnalyze.Interrupt_Flag_edit);
                             */
                            checkBox_owInterrupt = (CheckBox) mView.findViewById(R.id.checkBox_owInterrupt);
                            checkBox_owInterrupt.setChecked((BufferAnalyze.owInterrupt_edit==0)?false:true);
                            checkBox_owInterrupt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                    // TODO Auto-generated method stub
                                    if(isChecked==true){
                                        BufferAnalyze.owInterrupt_edit=1;
                                        BufferAnalyze.edit_mBuffer[936] |= 0x80;
                                        //BufferAnalyze.Interrupt_Flag_edit = BufferAnalyze.edit_mBuffer[936];
                                    }
                                    else{
                                        BufferAnalyze.owInterrupt_edit=0;
                                        BufferAnalyze.edit_mBuffer[936] &= ~0x80;
                                        //BufferAnalyze.Interrupt_Flag_edit = BufferAnalyze.edit_mBuffer[936];
                                    }
                                }
                            });

                            checkBox_ctInterrupt = (CheckBox) mView.findViewById(R.id.checkBox_ctInterrupt);
                            checkBox_ctInterrupt.setChecked((BufferAnalyze.ctInterrupt_edit==0)?false:true);
                            checkBox_ctInterrupt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                    // TODO Auto-generated method stub
                                    if(isChecked==true){
                                        BufferAnalyze.ctInterrupt_edit=1;
                                        BufferAnalyze.edit_mBuffer[936] |= 0x40;
                                        //BufferAnalyze.Interrupt_Flag_edit = BufferAnalyze.edit_mBuffer[936];
                                    }
                                    else{
                                        BufferAnalyze.ctInterrupt_edit=0;
                                        BufferAnalyze.edit_mBuffer[936] &= ~0x40;
                                        //BufferAnalyze.Interrupt_Flag_edit = BufferAnalyze.edit_mBuffer[936];
                                    }
                                }
                            });

                            checkBox_acInterrupt = (CheckBox) mView.findViewById(R.id.checkBox_acInterrupt);
                            checkBox_acInterrupt.setChecked((BufferAnalyze.acInterrupt_edit==0)?false:true);
                            checkBox_acInterrupt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                    // TODO Auto-generated method stub
                                    if(isChecked==true){
                                        BufferAnalyze.acInterrupt_edit=1;
                                        BufferAnalyze.edit_mBuffer[936] |= 0x20;
                                        //BufferAnalyze.Interrupt_Flag_edit = BufferAnalyze.edit_mBuffer[936];
                                    }
                                    else{
                                        BufferAnalyze.acInterrupt_edit=0;
                                        BufferAnalyze.edit_mBuffer[936] &= ~0x20;
                                        //BufferAnalyze.Interrupt_Flag_edit = BufferAnalyze.edit_mBuffer[936];
                                    }
                                }
                            });

                            checkBox_inputInterrupt = (CheckBox) mView.findViewById(R.id.checkBox_inputInterrupt);
                            checkBox_inputInterrupt.setChecked((BufferAnalyze.inputInterrupt_edit==0)?false:true);
                            checkBox_inputInterrupt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                    // TODO Auto-generated method stub
                                    if(isChecked==true){
                                        BufferAnalyze.inputInterrupt_edit=1;
                                        BufferAnalyze.edit_mBuffer[936] |= 0x10;
                                        //BufferAnalyze.Interrupt_Flag_edit = BufferAnalyze.edit_mBuffer[936];
                                    }
                                    else{
                                        BufferAnalyze.inputInterrupt_edit=0;
                                        BufferAnalyze.edit_mBuffer[936] &= ~0x10;
                                        //BufferAnalyze.Interrupt_Flag_edit = BufferAnalyze.edit_mBuffer[936];
                                    }
                                }
                            });

                            MQTTQoS_spinner  = (Spinner) mView.findViewById(R.id.MQTTQoS_spinner);
                            SpinAdapter2 MQTTQoS_adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option8);//simple_spinner_item 版面配置是由平台提供
                            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            MQTTQoS_spinner.setAdapter(MQTTQoS_adapter);
                            MQTTQoS_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    Log.d("IOT","選擇:");
                                    BufferAnalyze.MQTTQos_edit = (byte)position;
                                    BufferAnalyze.edit_mBuffer[934] = (byte)position;

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            MQTTQoS_spinner.setSelection((BufferAnalyze.MQTTQos_edit)>2?0:BufferAnalyze.MQTTQos_edit);


                            MQTTRetain_spinner  = (Spinner) mView.findViewById(R.id.MQTTRetain_spinner);
                            SpinAdapter2 MQTTRetain_adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option9);//simple_spinner_item 版面配置是由平台提供
                            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            MQTTRetain_spinner.setAdapter(MQTTRetain_adapter);
                            MQTTRetain_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    Log.d("IOT","選擇:");
                                    BufferAnalyze.MQTTRetain_edit = (byte)position;
                                    BufferAnalyze.edit_mBuffer[935] = (byte)position;

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            MQTTRetain_spinner.setSelection((BufferAnalyze.MQTTRetain_edit)>2?0:BufferAnalyze.MQTTRetain_edit);








                        }
                    }));
                }


            }
            return;

        }
    }

    @Override
    public void fillView() {
        new FillViewTask().execute(myTag);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println("BufferAnalyze.ca_mBuffer-1"+","+"requestCode="+requestCode+","+"resultCode="+resultCode);
        if(requestCode==0 && resultCode==RESULT_OK) {

            if (data != null) {
                BufferAnalyze.ca_fileUri = data.getData(); //The uri with the location of the file
                if (BufferAnalyze.ca_fileUri != null) {
                    //mSourceFileTextView.setText(mSelectedfileUri.getPath());
                    Log.d(TAG,"mSelectedfileUri.getPath():"+BufferAnalyze.ca_fileUri.getPath());
                    Log.d(TAG,"data.getDataString():"+data.getDataString());

                    String file_name = getFileName(mView.getContext(),data.getData());
                    Log.d(TAG,"file name:"+file_name);

                    char[] aaa = new char[32*1024*1024];
                    InputStream inputStream;
                    InputStreamReader inputStreamReader;

                    try {
                        inputStream = mView.getContext().getContentResolver().openInputStream(data.getData());
                        inputStreamReader = new InputStreamReader(inputStream,"ISO-8859-1");
                        BufferedReader br = new BufferedReader(inputStreamReader);

                        int fileSize =br.read(aaa,0,32*1024*1024); //inputStream.available();
                        System.out.println("fileSize="+fileSize);
                        BufferAnalyze.ca_mBuffer = new byte[fileSize];
                        for(int i=0;i<fileSize;i++){
                            BufferAnalyze.ca_mBuffer[i] = (byte)aaa[i];
                        }
                        /*
                        if(file_name.toLowerCase().contains(".pem")){
                            String s = new String(BufferAnalyze.ca_mBuffer, StandardCharsets.UTF_8);
                            if(s.toUpperCase().contains("BEGIN CERTIFICATE")) {
                                Log.d("IOT", "s.length():" + s.length());
                                s = s.replaceAll("\n", "");
                                byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                Log.d("IOT", "b.length():" + b.length);
                                BufferAnalyze.ca_mBuffer = new byte[b.length];
                                BufferAnalyze.ca_mBuffer = Arrays.copyOf(b, b.length);
                            }
                        }
                         */


                        System.out.println("BufferAnalyze.ca_mBuffer.length="+BufferAnalyze.ca_mBuffer.length);

                        if(BufferAnalyze.ca_mBuffer.length>2000){
                            getActivity().runOnUiThread (new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext(),"File Length Exceeded 2K Bytes. Please choose another file",Toast.LENGTH_LONG).show();
                                    //mNfcAdapter.disableReaderMode(getActivity());
                                }
                            }));
                            return;
                        }
                        else{
                            getActivity().runOnUiThread (new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext(),"Loaded CA File: "+file_name,Toast.LENGTH_LONG).show();
                                    //mNfcAdapter.disableReaderMode(getActivity());
                                }
                            }));
                        }

                        BufferAnalyze.load_CA_Cert_File_in_to_buffer();


                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                        return;
                    } catch (SecurityException se) {
                        se.printStackTrace();
                        return;
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                } else {
                    String filename = data.getDataString();
                    if (filename != null) {
                        //mSourceFileTextView.setText(Uri.parse(filename).getPath());
                        Log.d(TAG,"Uri.parse(filename).getPath():"+ Uri.parse(filename).getPath());
                    }
                }
            }
        }
        if(requestCode==1 && resultCode==RESULT_OK) {
            if (data != null) {
                BufferAnalyze.ClienCert_fileUri = data.getData(); //The uri with the location of the file
                if (BufferAnalyze.ClienCert_fileUri != null) {
                    //mSourceFileTextView.setText(mSelectedfileUri.getPath());
                    Log.d(TAG,"mSelectedfileUri.getPath():"+BufferAnalyze.ClienCert_fileUri.getPath());
                    Log.d(TAG,"data.getDataString():"+data.getDataString());
                    String file_name = getFileName(mView.getContext(),data.getData());
                    Log.d(TAG,"file name:"+file_name);

                    char[] aaa = new char[32*1024*1024];
                    InputStream inputStream;
                    InputStreamReader inputStreamReader;

                    try {
                        inputStream = mView.getContext().getContentResolver().openInputStream(data.getData());
                        inputStreamReader = new InputStreamReader(inputStream,"ISO-8859-1");
                        BufferedReader br = new BufferedReader(inputStreamReader);

                        int fileSize =br.read(aaa,0,32*1024*1024); //inputStream.available();
                        System.out.println("fileSize="+fileSize);

                        BufferAnalyze.ClienCert_mBuffer = new byte[fileSize];
                        for(int i=0;i<fileSize;i++){
                            BufferAnalyze.ClienCert_mBuffer[i] = (byte)aaa[i];
                        }
                        /*
                        if(file_name.toLowerCase().contains(".pem")){
                            String s = new String(BufferAnalyze.ClienCert_mBuffer, StandardCharsets.UTF_8);
                            if(s.toUpperCase().contains("BEGIN CERTIFICATE")) {

                                Log.d("IOT","s.length():"+s.length());
                                s = s.replaceAll("\n","");
                                byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                Log.d("IOT","b.length():"+b.length);
                                BufferAnalyze.ClienCert_mBuffer = new byte[b.length];
                                BufferAnalyze.ClienCert_mBuffer = Arrays.copyOf(b, b.length);

                            }

                        }
                        */


                        System.out.println("BufferAnalyze.ca_mBuffer.length="+BufferAnalyze.ClienCert_mBuffer.length);

                        if(BufferAnalyze.ClienCert_mBuffer.length>2000){
                            getActivity().runOnUiThread (new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext(),"File Length Exceeded 2K Bytes. Please choose another file",Toast.LENGTH_LONG).show();
                                    //mNfcAdapter.disableReaderMode(getActivity());
                                }
                            }));
                            return;
                        }
                        else{
                            getActivity().runOnUiThread (new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext(),"Loaded Client File: "+file_name,Toast.LENGTH_LONG).show();
                                    //mNfcAdapter.disableReaderMode(getActivity());
                                }
                            }));
                        }
                        BufferAnalyze.load_Client_Cert_File_in_to_buffer();


                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                        return;
                    } catch (SecurityException se) {
                        se.printStackTrace();
                        return;
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }




                } else {
                    String filename = data.getDataString();
                    if (filename != null) {
                        //mSourceFileTextView.setText(Uri.parse(filename).getPath());
                        Log.d(TAG,"Uri.parse(filename).getPath():"+ Uri.parse(filename).getPath());
                    }
                }
            }
        }
        if(requestCode==2 && resultCode==RESULT_OK) {
            if (data != null) {
                BufferAnalyze.UserKey_Cert_fileUri = data.getData(); //The uri with the location of the file
                if (BufferAnalyze.UserKey_Cert_fileUri != null) {
                    //mSourceFileTextView.setText(mSelectedfileUri.getPath());
                    Log.d(TAG,"mSelectedfileUri.getPath():"+BufferAnalyze.UserKey_Cert_fileUri.getPath());
                    Log.d(TAG,"data.getDataString():"+data.getDataString());
                    String file_name = getFileName(mView.getContext(),data.getData());
                    Log.d(TAG,"file name:"+file_name);

                    char[] aaa = new char[32*1024*1024];
                    InputStream inputStream;
                    InputStreamReader inputStreamReader;

                    try {
                        inputStream = mView.getContext().getContentResolver().openInputStream(data.getData());
                        inputStreamReader = new InputStreamReader(inputStream,"ISO-8859-1");
                        BufferedReader br = new BufferedReader(inputStreamReader);

                        int fileSize =br.read(aaa,0,32*1024*1024); //inputStream.available();
                        System.out.println("fileSize="+fileSize);

                        BufferAnalyze.UserKey_Cert_mBuffer = new byte[fileSize];
                        for(int i=0;i<fileSize;i++){
                            BufferAnalyze.UserKey_Cert_mBuffer[i] = (byte)aaa[i];
                        }
                        /*
                        if(file_name.toLowerCase().contains(".pem")){
                            String s = new String(BufferAnalyze.UserKey_Cert_mBuffer, StandardCharsets.UTF_8);
                            Log.d("IOT","s.length():"+s.length());
                            s = s.replaceAll("\n","");
                            byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                            Log.d("IOT","b.length():"+b.length);
                            BufferAnalyze.UserKey_Cert_mBuffer = new byte[b.length];
                            BufferAnalyze.UserKey_Cert_mBuffer = Arrays.copyOf(b, b.length);
                        }
                         */


                        System.out.println("BufferAnalyze.ca_mBuffer.length="+BufferAnalyze.UserKey_Cert_mBuffer.length);

                        if(BufferAnalyze.UserKey_Cert_mBuffer.length>2000){
                            getActivity().runOnUiThread (new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext(),"File Length Exceeded 2K Bytes. Please choose another file",Toast.LENGTH_LONG).show();
                                    //mNfcAdapter.disableReaderMode(getActivity());
                                }
                            }));
                            return;
                        }
                        else{
                            getActivity().runOnUiThread (new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext(),"Loaded User Key File: "+file_name,Toast.LENGTH_LONG).show();
                                    //mNfcAdapter.disableReaderMode(getActivity());
                                }
                            }));
                        }
                        BufferAnalyze.load_UserK_Cert_File_in_to_buffer();


                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                        return;
                    } catch (SecurityException se) {
                        se.printStackTrace();
                        return;
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }




                } else {
                    String filename = data.getDataString();
                    if (filename != null) {
                        //mSourceFileTextView.setText(Uri.parse(filename).getPath());
                        Log.d(TAG,"Uri.parse(filename).getPath():"+ Uri.parse(filename).getPath());
                    }
                }
            }
        }
    }
}
