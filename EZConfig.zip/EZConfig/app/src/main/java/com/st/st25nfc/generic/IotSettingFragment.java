/*
  * @author STMicroelectronics MMY Application team
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under ST MIX_MYLIBERTY SOFTWARE LICENSE AGREEMENT (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/Mix_MyLiberty
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied,
  * AND SPECIFICALLY DISCLAIMING THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
*/

package com.st.st25nfc.generic;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.Spinner;
import android.widget.TextView;

import com.st.st25nfc.R;
import com.st.st25nfc.generic.util.BufferAnalyze;
import com.st.st25sdk.Helper;
import com.st.st25sdk.NFCTag;
import com.st.st25sdk.STException;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

import static com.st.st25nfc.generic.MainActivity.is_next_jump;

public class IotSettingFragment extends STFragment {


    public static IotSettingFragment newInstance(Context context) {
        IotSettingFragment f = new IotSettingFragment();
        /* If needed, pass some argument to the fragment
        Bundle args = new Bundle();
        args.putInt("index", index);
        f.setArguments(args);
        */

        // Set the title of this fragment
        //f.setTitle(context.getResources().getString(R.string.tag_info));
        f.setTitle("Setting");

        return f;
    }

    public IotSettingFragment() {
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.fragment_iot_setting, container, false);
        mView = view;

        initView();
        return (View) view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private class FillViewTask extends STFragment.FillViewTask {


        LinearLayout di_port_group_LinearLayout;
        LinearLayout do_port_group_LinearLayout;
        LinearLayout NU_OW;
        EditText Device_ID;
        EditText iTempRPT;
        EditText _1_Wire_RPT;
        EditText CT_RPT;
        EditText GPS_RPT;
        EditText MODBIS_RPT;
        EditText InputInterv;
        LinearLayout MDB_R1_group;

        public FillViewTask() {
        }

        @Override
        protected Integer doInBackground(NFCTag... param) {

            return 0;
        }


        @Override
        protected void onPostExecute(Integer result) {

            if (result == 0) {
                if (mView != null) {

                    getActivity().runOnUiThread (new Thread(new Runnable() {
                        public void run() {
                            di_port_group_LinearLayout = (LinearLayout) mView.findViewById(R.id.di_port_group_LinearLayout);
                            do_port_group_LinearLayout = (LinearLayout) mView.findViewById(R.id.do_port_group_LinearLayout);
                            NU_OW = (LinearLayout) mView.findViewById(R.id.NU_OW);
                            MDB_R1_group = (LinearLayout) mView.findViewById(R.id.MDB_R1_group);
                            di_port_group_LinearLayout.removeAllViews();
                            do_port_group_LinearLayout.removeAllViews();
                            NU_OW.removeAllViews();
                            Device_ID = (EditText) mView.findViewById(R.id.Device_ID);
                            iTempRPT = (EditText) mView.findViewById(R.id.iTempRPT);
                            _1_Wire_RPT = (EditText) mView.findViewById(R.id._1_Wire_RPT);
                            CT_RPT = (EditText) mView.findViewById(R.id.CT_RPT);
                            GPS_RPT = (EditText) mView.findViewById(R.id.GPS_RPT);
                            MODBIS_RPT = (EditText) mView.findViewById(R.id.MODBIS_RPT);
                            InputInterv = (EditText) mView.findViewById(R.id.InputInterv);

                            Device_ID.setText(""+BufferAnalyze.Device_ID);
                            iTempRPT.setText(""+BufferAnalyze.iTempInterv_edit);
                            _1_Wire_RPT.setText(""+BufferAnalyze.OWInterv_edit);
                            CT_RPT.setText(""+BufferAnalyze.CTInterv_edit);
                            GPS_RPT.setText(""+BufferAnalyze.GPSInterv_edit);
                            MODBIS_RPT.setText(""+BufferAnalyze.MDBInterv_edit);
                            InputInterv.setText(""+BufferAnalyze.InputInterv_edit);


                            iTempRPT.setInputType(InputType.TYPE_CLASS_NUMBER);
                            _1_Wire_RPT.setInputType(InputType.TYPE_CLASS_NUMBER);
                            CT_RPT.setInputType(InputType.TYPE_CLASS_NUMBER);
                            GPS_RPT.setInputType(InputType.TYPE_CLASS_NUMBER);
                            MODBIS_RPT.setInputType(InputType.TYPE_CLASS_NUMBER);
                            InputInterv.setInputType(InputType.TYPE_CLASS_NUMBER);

                            InputInterv.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);
                                    for(int i=949;i<=952;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }
                                    if(b.length==1){
                                        BufferAnalyze.edit_mBuffer[949]=b[0];
                                        BufferAnalyze.edit_mBuffer[950]=0;
                                        BufferAnalyze.edit_mBuffer[951]=0;
                                        BufferAnalyze.edit_mBuffer[952]=0;
                                    }
                                    else if(b.length==2){
                                        BufferAnalyze.edit_mBuffer[949]=b[0];
                                        BufferAnalyze.edit_mBuffer[950]=b[1];
                                        BufferAnalyze.edit_mBuffer[951]=0;
                                        BufferAnalyze.edit_mBuffer[952]=0;
                                    }
                                    else if(b.length==3){
                                        BufferAnalyze.edit_mBuffer[949]=b[0];
                                        BufferAnalyze.edit_mBuffer[950]=b[1];
                                        BufferAnalyze.edit_mBuffer[951]=b[2];
                                        BufferAnalyze.edit_mBuffer[952]=0;
                                    }
                                    else if(b.length==4){
                                        int num = Integer.parseInt(cs.toString().trim());
                                        if(num>3600){
                                            InputInterv.setText("3600");
                                        }
                                        else{
                                            BufferAnalyze.edit_mBuffer[949]=b[0];
                                            BufferAnalyze.edit_mBuffer[950]=b[1];
                                            BufferAnalyze.edit_mBuffer[951]=b[2];
                                            BufferAnalyze.edit_mBuffer[952]=b[3];
                                        }

                                    }

                                    BufferAnalyze.InputInterv_edit = ""+InputInterv.getText();

                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });

                            iTempRPT.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                      String s = cs.toString().trim();
                                      Log.d("onTextChanged","s"+s);
                                      byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                      Log.d("onTextChanged","b.length"+b.length);
                                      for(int i=937;i<=940;i++){
                                          BufferAnalyze.edit_mBuffer[i]=0;
                                      }
                                      if(b.length==1){
                                          BufferAnalyze.edit_mBuffer[937]=b[0];
                                          BufferAnalyze.edit_mBuffer[938]=0;
                                          BufferAnalyze.edit_mBuffer[939]=0;
                                          BufferAnalyze.edit_mBuffer[940]=0;
                                      }
                                      else if(b.length==2){
                                          BufferAnalyze.edit_mBuffer[937]=b[0];
                                          BufferAnalyze.edit_mBuffer[938]=b[1];
                                          BufferAnalyze.edit_mBuffer[939]=0;
                                          BufferAnalyze.edit_mBuffer[940]=0;
                                      }
                                      else if(b.length==3){
                                          BufferAnalyze.edit_mBuffer[937]=b[0];
                                          BufferAnalyze.edit_mBuffer[938]=b[1];
                                          BufferAnalyze.edit_mBuffer[939]=b[2];
                                          BufferAnalyze.edit_mBuffer[940]=0;
                                      }
                                      else if(b.length==4){
                                          int num = Integer.parseInt(cs.toString().trim());
                                          if(num>3600){
                                              iTempRPT.setText("3600");
                                          }
                                          else{
                                              BufferAnalyze.edit_mBuffer[937]=b[0];
                                              BufferAnalyze.edit_mBuffer[938]=b[1];
                                              BufferAnalyze.edit_mBuffer[939]=b[2];
                                              BufferAnalyze.edit_mBuffer[940]=b[3];
                                          }
                                      }
                                      BufferAnalyze.iTempInterv_edit = ""+iTempRPT.getText();

                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });
                            _1_Wire_RPT.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);
                                    for(int i=941;i<=944;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }
                                    if(b.length==1){
                                        BufferAnalyze.edit_mBuffer[941]=b[0];
                                        BufferAnalyze.edit_mBuffer[942]=0;
                                        BufferAnalyze.edit_mBuffer[943]=0;
                                        BufferAnalyze.edit_mBuffer[944]=0;
                                    }
                                    else if(b.length==2){
                                        BufferAnalyze.edit_mBuffer[941]=b[0];
                                        BufferAnalyze.edit_mBuffer[942]=b[1];
                                        BufferAnalyze.edit_mBuffer[943]=0;
                                        BufferAnalyze.edit_mBuffer[944]=0;
                                    }
                                    else if(b.length==3){
                                        BufferAnalyze.edit_mBuffer[941]=b[0];
                                        BufferAnalyze.edit_mBuffer[942]=b[1];
                                        BufferAnalyze.edit_mBuffer[943]=b[2];
                                        BufferAnalyze.edit_mBuffer[944]=0;
                                    }
                                    else if(b.length==4){
                                        int num = Integer.parseInt(cs.toString().trim());
                                        if(num>3600){
                                            _1_Wire_RPT.setText("3600");
                                        }
                                        else{
                                            BufferAnalyze.edit_mBuffer[941]=b[0];
                                            BufferAnalyze.edit_mBuffer[942]=b[1];
                                            BufferAnalyze.edit_mBuffer[943]=b[2];
                                            BufferAnalyze.edit_mBuffer[944]=b[3];
                                        }

                                    }
                                    BufferAnalyze.OWInterv_edit = ""+_1_Wire_RPT.getText();
                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });
                            CT_RPT.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);
                                    for(int i=945;i<=948;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }
                                    if(b.length==1){
                                        BufferAnalyze.edit_mBuffer[945]=b[0];
                                        BufferAnalyze.edit_mBuffer[946]=0;
                                        BufferAnalyze.edit_mBuffer[947]=0;
                                        BufferAnalyze.edit_mBuffer[948]=0;
                                    }
                                    else if(b.length==2){
                                        BufferAnalyze.edit_mBuffer[945]=b[0];
                                        BufferAnalyze.edit_mBuffer[946]=b[1];
                                        BufferAnalyze.edit_mBuffer[947]=0;
                                        BufferAnalyze.edit_mBuffer[948]=0;
                                    }
                                    else if(b.length==3){
                                        BufferAnalyze.edit_mBuffer[945]=b[0];
                                        BufferAnalyze.edit_mBuffer[946]=b[1];
                                        BufferAnalyze.edit_mBuffer[947]=b[2];
                                        BufferAnalyze.edit_mBuffer[948]=0;
                                    }
                                    else if(b.length==4){
                                        int num = Integer.parseInt(cs.toString().trim());
                                        if(num>3600){
                                            CT_RPT.setText("3600");
                                        }
                                        else{
                                            BufferAnalyze.edit_mBuffer[945]=b[0];
                                            BufferAnalyze.edit_mBuffer[946]=b[1];
                                            BufferAnalyze.edit_mBuffer[947]=b[2];
                                            BufferAnalyze.edit_mBuffer[948]=b[3];
                                        }

                                    }

                                    BufferAnalyze.CTInterv_edit = ""+CT_RPT.getText();
                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });
                            GPS_RPT.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);
                                    for(int i=957;i<=960;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }
                                    if(b.length==1){
                                        BufferAnalyze.edit_mBuffer[957]=b[0];
                                        BufferAnalyze.edit_mBuffer[958]=0;
                                        BufferAnalyze.edit_mBuffer[950]=0;
                                        BufferAnalyze.edit_mBuffer[960]=0;
                                    }
                                    else if(b.length==2){
                                        BufferAnalyze.edit_mBuffer[957]=b[0];
                                        BufferAnalyze.edit_mBuffer[958]=b[1];
                                        BufferAnalyze.edit_mBuffer[959]=0;
                                        BufferAnalyze.edit_mBuffer[960]=0;
                                    }
                                    else if(b.length==3){
                                        BufferAnalyze.edit_mBuffer[957]=b[0];
                                        BufferAnalyze.edit_mBuffer[958]=b[1];
                                        BufferAnalyze.edit_mBuffer[959]=b[2];
                                        BufferAnalyze.edit_mBuffer[960]=0;
                                    }
                                    else if(b.length==4){
                                        int num = Integer.parseInt(cs.toString().trim());
                                        if(num>3600){
                                            GPS_RPT.setText("3600");
                                        }
                                        else{
                                            BufferAnalyze.edit_mBuffer[957]=b[0];
                                            BufferAnalyze.edit_mBuffer[958]=b[1];
                                            BufferAnalyze.edit_mBuffer[959]=b[2];
                                            BufferAnalyze.edit_mBuffer[960]=b[3];
                                        }

                                    }
                                    BufferAnalyze.GPSInterv_edit = ""+GPS_RPT.getText();
                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });
                            MODBIS_RPT.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);
                                    for(int i=953;i<=956;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }
                                    if(b.length==1){
                                        BufferAnalyze.edit_mBuffer[953]=b[0];
                                        BufferAnalyze.edit_mBuffer[954]=0;
                                        BufferAnalyze.edit_mBuffer[955]=0;
                                        BufferAnalyze.edit_mBuffer[956]=0;
                                    }
                                    else if(b.length==2){
                                        BufferAnalyze.edit_mBuffer[953]=b[0];
                                        BufferAnalyze.edit_mBuffer[954]=b[1];
                                        BufferAnalyze.edit_mBuffer[955]=0;
                                        BufferAnalyze.edit_mBuffer[956]=0;
                                    }
                                    else if(b.length==3){
                                        BufferAnalyze.edit_mBuffer[953]=b[0];
                                        BufferAnalyze.edit_mBuffer[954]=b[1];
                                        BufferAnalyze.edit_mBuffer[955]=b[2];
                                        BufferAnalyze.edit_mBuffer[956]=0;
                                    }
                                    else if(b.length==4){

                                        int num = Integer.parseInt(cs.toString().trim());
                                        if(num>3600){
                                            MODBIS_RPT.setText("3600");
                                        }
                                        else {
                                            BufferAnalyze.edit_mBuffer[953] = b[0];
                                            BufferAnalyze.edit_mBuffer[954] = b[1];
                                            BufferAnalyze.edit_mBuffer[955] = b[2];
                                            BufferAnalyze.edit_mBuffer[956] = b[3];
                                        }
                                    }


                                    BufferAnalyze.MDBInterv_edit = ""+MODBIS_RPT.getText();

                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });


                            int myNum = 0;
                            try {
                                myNum = Integer.parseInt(""+BufferAnalyze.Number_of_Digital_Input);
                            } catch(NumberFormatException nfe) {
                                System.out.println("Could not parse " + nfe);
                            }
                            System.out.println("IotSettingFragment: myNum " + myNum);
                            for(int i = 0; i<(myNum); i++){
                                TextView t = new TextView(mView.getContext());
                                t.setText("DI Port -"+(i));
                                LinearLayout ll = new LinearLayout(mView.getContext());

                                ll.setOrientation(LinearLayout.HORIZONTAL);
                                TextView title = new TextView(mView.getContext());
                                title.setText("Digital Input Configuration");
                                //v.setText(""+BufferAnalyze.option1.get(BufferAnalyze.DI_Port_group_LinearLayout[i]));
                                t.setTypeface(t.getTypeface(), Typeface.BOLD);
                                //v.setTypeface(t.getTypeface(), Typeface.BOLD);
                                Space s = new Space(mView.getContext());
                                Spinner spinner = new Spinner(mView.getContext());
                                SpinAdapter2 adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option1);//simple_spinner_item 版面配置是由平台提供
                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                spinner.setAdapter(adapter);
                                int finalI = i;
                                spinner.setSelection(BufferAnalyze.DI_Port_group_LinearLayout_edit[i]);
                                spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                        BufferAnalyze.DI_Port_group_LinearLayout_edit[finalI] = (byte)position;

                                        if(finalI==0){
                                            BufferAnalyze.edit_mBuffer[300]=(byte)(((BufferAnalyze.edit_mBuffer[300] & ~(byte)0x03)) | (byte)position);
                                            Log.d("IOT","BufferAnalyze.mBuffer[300]="+ BufferAnalyze.edit_mBuffer[300]+",0");
                                        }
                                        else if(finalI==1){
                                            BufferAnalyze.edit_mBuffer[300]=(byte)((BufferAnalyze.edit_mBuffer[300] & ~(byte)0x0c) | (byte)position<<2);
                                            Log.d("IOT","BufferAnalyze.mBuffer[300]"+ BufferAnalyze.edit_mBuffer[300]+",1");
                                        }
                                        else if(finalI==2){
                                            BufferAnalyze.edit_mBuffer[300]=(byte)((BufferAnalyze.edit_mBuffer[300] & ~(byte)0x30) | (byte)position<<4);
                                            Log.d("IOT","BufferAnalyze.mBuffer[300]"+ BufferAnalyze.edit_mBuffer[300]+",2");
                                        }
                                        else if(finalI==3){
                                            BufferAnalyze.edit_mBuffer[300]=(byte)((BufferAnalyze.edit_mBuffer[300] & ~(byte)0xc0) | (byte)position<<6);
                                        }
                                        else if(finalI==4){
                                            BufferAnalyze.edit_mBuffer[299]=(byte)((BufferAnalyze.edit_mBuffer[299] & ~(byte)0x03) | (byte)position);
                                        }
                                        else if(finalI==5){
                                            BufferAnalyze.edit_mBuffer[299]=(byte)((BufferAnalyze.edit_mBuffer[299] & ~(byte)0x0c) | (byte)position<<2);
                                        }
                                        else if(finalI==6){
                                            BufferAnalyze.edit_mBuffer[299]=(byte)((BufferAnalyze.edit_mBuffer[299] & ~(byte)0x30) | (byte)position<<4);
                                        }
                                        else if(finalI==7){
                                            BufferAnalyze.edit_mBuffer[299]=(byte)((BufferAnalyze.edit_mBuffer[299] & ~(byte)0xc0) | (byte)position<<6);
                                        }
                                        else if(finalI==8){
                                            BufferAnalyze.edit_mBuffer[298]=(byte)((BufferAnalyze.edit_mBuffer[298] & ~(byte)0x03) | (byte)position);
                                        }
                                        else if(finalI==9){
                                            BufferAnalyze.mBuffer[298]=(byte)((BufferAnalyze.edit_mBuffer[298] & ~(byte)0x0c) | (byte)position<<2);
                                        }
                                        else if(finalI==10){
                                            BufferAnalyze.edit_mBuffer[298]=(byte)((BufferAnalyze.edit_mBuffer[298] & ~(byte)0x30) | (byte)position<<4);
                                        }
                                        else if(finalI==11){
                                            BufferAnalyze.edit_mBuffer[298]=(byte)((BufferAnalyze.edit_mBuffer[298] & ~(byte)0xc0) | (byte)position<<6);
                                        }
                                        else if(finalI==12){
                                            BufferAnalyze.edit_mBuffer[297]=(byte)((BufferAnalyze.edit_mBuffer[297] & ~(byte)0x03) | (byte)position);
                                        }
                                        else if(finalI==13){
                                            BufferAnalyze.edit_mBuffer[297]=(byte)((BufferAnalyze.edit_mBuffer[297] & ~(byte)0x0c) | (byte)position<<2);
                                        }
                                        else if(finalI==14){
                                            BufferAnalyze.edit_mBuffer[297]=(byte)((BufferAnalyze.edit_mBuffer[297] & ~(byte)0x30) | (byte)position<<4);
                                        }
                                        else if(finalI==15){
                                            BufferAnalyze.edit_mBuffer[297]=(byte)((BufferAnalyze.edit_mBuffer[297] & ~(byte)0xc0) | (byte)position<<6);
                                        }
                                        //BufferAnalyze.analyze();
                                        //Log.d("IOT","BufferAnalyze.mBuffer[300]"+ BufferAnalyze.mBuffer[300]+",999");

                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent) {

                                    }
                                });
                                s.setLayoutParams(new LinearLayout.LayoutParams(20,LinearLayout.LayoutParams.WRAP_CONTENT));
                                ll.addView(title);
                                ll.addView(s);
                                ll.addView(spinner);
                                di_port_group_LinearLayout.addView(t);
                                di_port_group_LinearLayout.addView(ll);

                            }

                            try {
                                myNum = Integer.parseInt(""+BufferAnalyze.Number_of_Digital_Output);
                            } catch(NumberFormatException nfe) {
                                System.out.println("Could not parse " + nfe);
                            }
                            for(int i=0;i<(myNum);i++){
                                TextView t = new TextView(mView.getContext());
                                t.setText("DO Port -"+(i));
                                LinearLayout ll = new LinearLayout(mView.getContext());

                                ll.setOrientation(LinearLayout.HORIZONTAL);
                                TextView title = new TextView(mView.getContext());
                                title.setText("Digital Output Configuration");
                                //v.setText(""+BufferAnalyze.option1.get(BufferAnalyze.DI_Port_group_LinearLayout[i]));
                                t.setTypeface(t.getTypeface(), Typeface.BOLD);
                                //v.setTypeface(t.getTypeface(), Typeface.BOLD);
                                Space s = new Space(mView.getContext());
                                Spinner spinner = new Spinner(mView.getContext());
                                SpinAdapter2 adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option7);//simple_spinner_item 版面配置是由平台提供
                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                System.out.println("BufferAnalyze.DI_Port_group_LinearLayout["+i+"]=" + BufferAnalyze.DO_Port_group_LinearLayout[i]);
                                spinner.setAdapter(adapter);
                                int finalI = i;
                                spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                        Log.d("IOT","選擇:");

                                        BufferAnalyze.DO_Port_group_LinearLayout_edit[finalI]=(byte)position;

                                        if(finalI==0){
                                            BufferAnalyze.edit_mBuffer[308]=(byte)((BufferAnalyze.edit_mBuffer[308] & ~(byte)0x03) | (byte)position);
                                        }
                                        else if(finalI==1){
                                            BufferAnalyze.edit_mBuffer[308]=(byte)((BufferAnalyze.edit_mBuffer[308] & ~(byte)0x0c) | (byte)position<<2);
                                        }
                                        else if(finalI==2){
                                            BufferAnalyze.edit_mBuffer[308]=(byte)((BufferAnalyze.edit_mBuffer[308] & ~(byte)0x30) | (byte)position<<4);
                                        }
                                        else if(finalI==3){
                                            BufferAnalyze.edit_mBuffer[308]=(byte)((BufferAnalyze.edit_mBuffer[308] & ~(byte)0xc0) | (byte)position<<6);
                                        }
                                        else if(finalI==4){
                                            BufferAnalyze.edit_mBuffer[307]=(byte)((BufferAnalyze.edit_mBuffer[307] & ~(byte)0x03) | (byte)position);
                                        }
                                        else if(finalI==5){
                                            BufferAnalyze.edit_mBuffer[307]=(byte)((BufferAnalyze.edit_mBuffer[307] & ~(byte)0x0c) | (byte)position<<2);
                                        }
                                        else if(finalI==6){
                                            BufferAnalyze.edit_mBuffer[307]=(byte)((BufferAnalyze.edit_mBuffer[307] & ~(byte)0x30) | (byte)position<<4);
                                        }
                                        else if(finalI==7){
                                            BufferAnalyze.edit_mBuffer[307]=(byte)((BufferAnalyze.edit_mBuffer[307] & ~(byte)0xc0) | (byte)position<<6);
                                        }
                                        else if(finalI==8){
                                            BufferAnalyze.edit_mBuffer[306]=(byte)((BufferAnalyze.edit_mBuffer[306] & ~(byte)0x03) | (byte)position);
                                        }
                                        else if(finalI==9){
                                            BufferAnalyze.edit_mBuffer[306]=(byte)((BufferAnalyze.edit_mBuffer[306] & ~(byte)0x0c) | (byte)position<<2);
                                        }
                                        else if(finalI==10){
                                            BufferAnalyze.edit_mBuffer[306]=(byte)((BufferAnalyze.edit_mBuffer[306] & ~(byte)0x30) | (byte)position<<4);
                                        }
                                        else if(finalI==11){
                                            BufferAnalyze.edit_mBuffer[306]=(byte)((BufferAnalyze.edit_mBuffer[306] & ~(byte)0xc0) | (byte)position<<6);
                                        }
                                        else if(finalI==12){
                                            BufferAnalyze.edit_mBuffer[305]=(byte)((BufferAnalyze.edit_mBuffer[305] & ~(byte)0x03) | (byte)position);
                                        }
                                        else if(finalI==13){
                                            BufferAnalyze.edit_mBuffer[305]=(byte)((BufferAnalyze.edit_mBuffer[305] & ~(byte)0x0c) | (byte)position<<2);
                                        }
                                        else if(finalI==14){
                                            BufferAnalyze.edit_mBuffer[305]=(byte)((BufferAnalyze.edit_mBuffer[305] & ~(byte)0x30) | (byte)position<<4);
                                        }
                                        else if(finalI==15){
                                            BufferAnalyze.edit_mBuffer[305]=(byte)((BufferAnalyze.edit_mBuffer[305] & ~(byte)0xc0) | (byte)position<<6);
                                        }
                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent) {

                                    }
                                });
                                spinner.setSelection(BufferAnalyze.DO_Port_group_LinearLayout_edit[i]);
                                s.setLayoutParams(new LinearLayout.LayoutParams(20,LinearLayout.LayoutParams.WRAP_CONTENT));
                                ll.addView(title);
                                ll.addView(s);
                                ll.addView(spinner);
                                do_port_group_LinearLayout.addView(t);
                                do_port_group_LinearLayout.addView(ll);

                            }



                            TextView t = new TextView(mView.getContext());
                            t.setText("NU - OW");
                            LinearLayout ll = new LinearLayout(mView.getContext());

                            ll.setOrientation(LinearLayout.HORIZONTAL);
                            TextView title = new TextView(mView.getContext());
                            title.setText("number of 1-wire devices");
                            //v.setText(""+BufferAnalyze.option1.get(BufferAnalyze.DI_Port_group_LinearLayout[i]));
                            t.setTypeface(t.getTypeface(), Typeface.BOLD);
                            //v.setTypeface(t.getTypeface(), Typeface.BOLD);
                            Space s = new Space(mView.getContext());
                            Spinner spinner = new Spinner(mView.getContext());
                            SpinAdapter2 adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option3);//simple_spinner_item 版面配置是由平台提供
                            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            spinner.setAdapter(adapter);
                            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    Log.d("IOT","選擇:");
                                    BufferAnalyze.NU_OW_edit = position;
                                    BufferAnalyze.edit_mBuffer[317]=(byte)(position/256);
                                    BufferAnalyze.edit_mBuffer[318]=(byte)(position%256);
                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            spinner.setSelection(BufferAnalyze.NU_OW_edit);
                            s.setLayoutParams(new LinearLayout.LayoutParams(20,LinearLayout.LayoutParams.WRAP_CONTENT));
                            ll.addView(title);
                            ll.addView(s);
                            ll.addView(spinner);
                            NU_OW.addView(t);
                            NU_OW.addView(ll);



                            MDB_R1_group.removeAllViews();
                            for(int i=0;i<20;i++){
                                LinearLayout l1 = new LinearLayout(mView.getContext());
                                l1.setOrientation(LinearLayout.HORIZONTAL);
                                TextView t1_1 = new TextView(mView.getContext());
                                TextView t1_2 = new TextView(mView.getContext());
                                Space s1 = new Space(mView.getContext());
                                s1.setLayoutParams(new LinearLayout.LayoutParams(20,LinearLayout.LayoutParams.WRAP_CONTENT));
                                t1_1.setText("MDB CMD"+(i+1));
                                t1_2.setText("Modbus Command Stream "+(i+1));
                                l1.addView(t1_1);
                                l1.addView(s1);
                                l1.addView(t1_2);

                                LinearLayout l2 = new LinearLayout(mView.getContext());
                                l2.setOrientation(LinearLayout.HORIZONTAL);
                                TextView t2_1 = new TextView(mView.getContext());
                                TextView t2_2 = new TextView(mView.getContext());
                                TextView t2_3 = new TextView(mView.getContext());
                                TextView t2_4 = new TextView(mView.getContext());
                                t2_1.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                                t2_2.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                                t2_3.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                                t2_4.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                                t2_1.setText("Slave Address");
                                t2_2.setText("Function Code");
                                t2_3.setText("Register Address");
                                t2_4.setText("Number of Register");
                                l2.addView(t2_1);
                                l2.addView(t2_2);
                                l2.addView(t2_3);
                                l2.addView(t2_4);

                                LinearLayout l3 = new LinearLayout(mView.getContext());
                                l3.setOrientation(LinearLayout.HORIZONTAL);
                                EditText Slave_Address = new EditText(mView.getContext());
                                Slave_Address.setInputType(InputType.TYPE_CLASS_NUMBER);
                                Slave_Address.setTextSize(12);
                                Slave_Address.setFilters(new InputFilter[] {new InputFilter.LengthFilter(1)});
                                //Slave_Address.setText(""+String.format("%04X", (BufferAnalyze.MDB_Rx_group.get(i).Slave_Address)));
                                Slave_Address.setText((BufferAnalyze.MDB_Rx_group_edit.size()==0)?"":""+(BufferAnalyze.MDB_Rx_group_edit.get(i).Slave_Address));
                                int finalI = i;
                                int finalI_index = i*6;
                                Slave_Address.addTextChangedListener(new TextWatcher() {

                                    @Override
                                    public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                        String s = cs.toString().trim();
                                        Log.d("onTextChanged","s"+s);
                                        byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                        Log.d("onTextChanged","b.length"+b.length);

                                        if(b.length==1) {
                                            int num = Integer.parseInt(cs.toString().trim());
                                            if (num > 4) {
                                                Slave_Address.setText("4");
                                            } else {
                                                BufferAnalyze.edit_mBuffer[7357 + finalI_index] = (byte)num;
                                                BufferAnalyze.MDB_Rx_group_edit.get(finalI).Slave_Address = (byte)num;
                                            }
                                        }


                                    }

                                    @Override
                                    public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                    }

                                    @Override
                                    public void afterTextChanged(Editable arg0) {

                                    }

                                });
                                Spinner Function_Code_spinner = new Spinner(mView.getContext());
                                SpinAdapter2 Function_Code_adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option4);//simple_spinner_item 版面配置是由平台提供
                                Function_Code_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                Function_Code_spinner.setAdapter(Function_Code_adapter);
                                Function_Code_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                        Log.d("IOT","選擇:");

                                        BufferAnalyze.edit_mBuffer[7357+3+finalI_index] = (byte)position;
                                        BufferAnalyze.MDB_Rx_group_edit.get(finalI).Function_Code = (byte)position;

                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent) {

                                    }
                                });
                                Function_Code_spinner.setSelection(BufferAnalyze.MDB_Rx_group_edit.get(i).Function_Code);
                                TextView Register_Address_label = new TextView(mView.getContext());
                                Register_Address_label.setText("0x");
                                Register_Address_label.setTextSize(12);
                                EditText Register_Address = new EditText(mView.getContext());
                                Register_Address.setTextSize(12);
                                Register_Address.setFilters(new InputFilter[] {new InputFilter.LengthFilter(4)});
                                Register_Address.setKeyListener(DigitsKeyListener.getInstance("0123456789abcdefABCDEF"));
                                Register_Address.setRawInputType(InputType.TYPE_TEXT_VARIATION_PERSON_NAME);
                                Register_Address.setText(""+String.format("%04X", (BufferAnalyze.MDB_Rx_group_edit.get(i).Register_Address)));
                                Register_Address.addTextChangedListener(new TextWatcher() {

                                    @Override
                                    public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                        String s = cs.toString().trim().toLowerCase();
                                        Log.d("onTextChanged","s"+s);
                                        byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                        Log.d("onTextChanged","b.length"+b.length);

                                        if(b.length>0) {
                                            BufferAnalyze.MDB_Rx_group_edit.get(finalI).Register_Address = Integer.parseInt(s, 16);
                                            Log.d("onTextChanged","BufferAnalyze.MDB_Rx_group_edit.get(finalI).Register_Address:"+BufferAnalyze.MDB_Rx_group_edit.get(finalI).Register_Address);
                                            BufferAnalyze.edit_mBuffer[7357 + 1 + finalI_index] = (byte)((BufferAnalyze.MDB_Rx_group_edit.get(finalI).Register_Address >> 8) & 0xff);
                                            BufferAnalyze.edit_mBuffer[7357 + 2 + finalI_index] = (byte)(BufferAnalyze.MDB_Rx_group_edit.get(finalI).Register_Address & 0xff);
                                            Log.d("onTextChanged","BufferAnalyze.edit_mBuffer[7357 + 1 + finalI_index]:"+BufferAnalyze.edit_mBuffer[7357 + 1 + finalI_index]);
                                            Log.d("onTextChanged","BufferAnalyze.edit_mBuffer[7357 + 2 + finalI_index]:"+BufferAnalyze.edit_mBuffer[7357 + 2 + finalI_index]);
                                        }
                                    }

                                    @Override
                                    public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                    }

                                    @Override
                                    public void afterTextChanged(Editable arg0) {

                                    }

                                });

                                TextView Number_of_Register_label = new TextView(mView.getContext());
                                Number_of_Register_label.setText("0x");
                                Number_of_Register_label.setTextSize(12);
                                EditText Number_of_Register = new EditText(mView.getContext());
                                Number_of_Register.setTextSize(12);
                                Number_of_Register.setFilters(new InputFilter[] {new InputFilter.LengthFilter(4)});
                                Number_of_Register.setKeyListener(DigitsKeyListener.getInstance("0123456789abcdefABCDEF"));
                                Number_of_Register.setRawInputType(InputType.TYPE_TEXT_VARIATION_PERSON_NAME);
                                Number_of_Register.addTextChangedListener(new TextWatcher() {

                                    @Override
                                    public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                        String s = cs.toString().trim().toLowerCase();
                                        Log.d("onTextChanged","s"+s);
                                        byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                        Log.d("onTextChanged","b.length"+b.length);

                                        if(b.length>0) {
                                            BufferAnalyze.MDB_Rx_group_edit.get(finalI).Number_of_Register = Integer.parseInt(s, 16);
                                            BufferAnalyze.edit_mBuffer[7357 + 4 + finalI_index] = (byte)((BufferAnalyze.MDB_Rx_group_edit.get(finalI).Number_of_Register >> 8) & 0xff);
                                            BufferAnalyze.edit_mBuffer[7357 + 5 + finalI_index] = (byte)(BufferAnalyze.MDB_Rx_group_edit.get(finalI).Number_of_Register & 0xff);
                                        }
                                    }

                                    @Override
                                    public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                    }

                                    @Override
                                    public void afterTextChanged(Editable arg0) {

                                    }

                                });
                                Number_of_Register.setText(String.format("%04X", (BufferAnalyze.MDB_Rx_group_edit.get(i).Number_of_Register)));


                                Slave_Address.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                                Function_Code_spinner.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.5f));
                                Register_Address.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                                Number_of_Register.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                                l3.addView(Slave_Address);
                                l3.addView(Function_Code_spinner);
                                l3.addView(Register_Address_label);
                                l3.addView(Register_Address);
                                l3.addView(Number_of_Register_label);
                                l3.addView(Number_of_Register);

                                Space s_h = new Space(mView.getContext());
                                s_h.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,40));

                                MDB_R1_group.addView(l1);
                                MDB_R1_group.addView(l2);
                                MDB_R1_group.addView(l3);
                                MDB_R1_group.addView(s_h);
                            }



                        }
                    }));


                }

            }
            return;

        }
    }

    @Override
    public void fillView() {
        new FillViewTask().execute(myTag);
    }
}
