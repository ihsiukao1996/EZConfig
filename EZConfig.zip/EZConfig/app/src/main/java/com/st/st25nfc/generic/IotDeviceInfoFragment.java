/*
  * @author STMicroelectronics MMY Application team
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under ST MIX_MYLIBERTY SOFTWARE LICENSE AGREEMENT (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/Mix_MyLiberty
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied,
  * AND SPECIFICALLY DISCLAIMING THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
*/

package com.st.st25nfc.generic;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

import com.st.st25nfc.R;
import com.st.st25nfc.generic.util.BufferAnalyze;
import com.st.st25nfc.generic.util.UIHelper;
import com.st.st25sdk.Helper;
import com.st.st25sdk.MultiAreaInterface;
import com.st.st25sdk.NFCTag;
import com.st.st25sdk.STException;
import com.st.st25sdk.type4a.FileControlTlvType4;
import com.st.st25sdk.type4a.STType4Tag;
import com.st.st25sdk.type4a.Type4Tag;

import java.util.Arrays;

import static com.st.st25nfc.generic.MainActivity.is_next_jump;
import static com.st.st25sdk.MultiAreaInterface.AREA1;

public class IotDeviceInfoFragment extends STFragment {



    public static IotDeviceInfoFragment newInstance(Context context) {
        IotDeviceInfoFragment f = new IotDeviceInfoFragment();
        /* If needed, pass some argument to the fragment
        Bundle args = new Bundle();
        args.putInt("index", index);
        f.setArguments(args);
        */

        // Set the title of this fragment
        //f.setTitle(context.getResources().getString(R.string.tag_info));
        f.setTitle("Device Info");

        return f;
    }

    public IotDeviceInfoFragment() {
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.fragment_device_info, container, false);
        mView = view;

        initView();
        return (View) view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private class FillViewTask extends STFragment.FillViewTask {

        TextView mUidView;
        TextView mManufacturerNameView;
        TextView mTagNameView;
        TextView mTagDescriptionView;
        TextView mTagTypeView;
        TextView mTagSizeView;
        TextView mTechListView;

        String mManufacturerName;
        String mUid;
        String mTagName;
        String mTagDescription;
        String mTagType;
        String mTagSize;
        String mTechList;

        TextView mMOD_NAME_View;
        TextView deviceID;
        TextView mIMEIView;
        TextView mFW_Version;
        TextView UUID;
        TextView Number_of_Digital_Input;
        TextView Number_of_Digital_Output;
        TextView RS485;
        TextView _1_wire;
        TextView RS232;
        TextView Network_Type;
        TextView Number_of_AI;

        LinearLayout DI_Port_group_LinearLayout;
        LinearLayout DO_Port_group_LinearLayout;
        LinearLayout network_group_LinearLayout;

        TextView MQTTHost;
        TextView MQTTClient;
        TextView MQTTPwd;
        TextView MQTTTopic;
        TextView MQTTSub;
        TextView MQTTVer;
        TextView MQTTPort;
        TextView MQTTLive;
        TextView Interrupt_Flag;
        TextView iTempInterv;
        TextView OWInterv;
        TextView CTInterv;
        TextView InputInterv;
        TextView MDBInterv;
        TextView GPSInterv;
        TextView SSL;
        TextView SNI;
        TextView CA_Certification;
        TextView ClientKey_Cert;
        TextView UserKey_Cert;
        TextView RTC;
        TextView M1_Band;
        TextView NB_Band;
        TextView PDP_Type;
        TextView APN;
        TextView PDP_Config_Data;
        TextView PDP_Config_Header;
        TextView MQTTQos;
        TextView MQTTRetain;
        TextView Roam_Flag;


        public FillViewTask() {
        }


        private int getMemoryAreaSizeInBytes(Type4Tag myTag, int area) {
            int memoryAreaSizeInBytes = 0;
            try {
                if (myTag instanceof STType4Tag) {

                    int fileId = UIHelper.getType4FileIdFromArea(area);
                    FileControlTlvType4 controlTlv = ((STType4Tag) myTag).getCCFileTlv(fileId);

                    memoryAreaSizeInBytes = controlTlv.getMaxFileSize();

                }  else {
                    if (myTag instanceof MultiAreaInterface) {
                        memoryAreaSizeInBytes = ((MultiAreaInterface) myTag).getAreaSizeInBytes(area);
                    } else {
                        memoryAreaSizeInBytes = myTag.getMemSizeInBytes();
                    }
                }
            } catch (STException e) {
                e.printStackTrace();
            }
            return memoryAreaSizeInBytes;
        }

        @Override
        protected Integer doInBackground(NFCTag... param) {

            int mNumberOfBytes;
            int mStartAddress;
            int  mArea = AREA1;

            try {

                if(BufferAnalyze.is_edit1==true){return 0;}

                if(is_next_jump==false) {

                    if (UIHelper.isAType4Tag(myTag)) {
                        // Tag type 4
                        int size = getMemoryAreaSizeInBytes(((Type4Tag) myTag), mArea);
                        mNumberOfBytes = size;
                        mStartAddress = 0;
                        Log.d("IOT","mNumberOfBytes:"+mNumberOfBytes);

                        int fileId = UIHelper.getType4FileIdFromArea(mArea);

                        Log.d("IOT","fileId:"+fileId);

                        if(((STType4Tag) myTag).isReadPasswordRequested(fileId)) {
                            BufferAnalyze.mBuffer = ((STType4Tag) myTag).readBytes(fileId, 0, size, BufferAnalyze.voyagerReadPass);
                        }
                        else {
                            BufferAnalyze.mBuffer = ((Type4Tag) myTag).readBytes(fileId, 0, size);
                        }
                        BufferAnalyze.edit_mBuffer = Arrays.copyOf(BufferAnalyze.mBuffer, BufferAnalyze.mBuffer.length);


                        int nbrOfBytesRead = 0;
                        if (BufferAnalyze.mBuffer != null) {
                            nbrOfBytesRead = BufferAnalyze.mBuffer.length;
                            Log.d("IOT","mBuffer.length:"+BufferAnalyze.mBuffer.length);
                            for(int i=0;i<BufferAnalyze.mBuffer.length/4;) {
                                Log.d("IOT", "addr("+i+")" + String.format("%02X ", BufferAnalyze.mBuffer[i])+","+String.format("%02X ", BufferAnalyze.mBuffer[i+1])+","+String.format("%02X ", BufferAnalyze.mBuffer[i+2])+","+String.format("%02X ", BufferAnalyze.mBuffer[i+3]));
                                i+=4;
                            }
                            Log.d("IOT","BufferAnalyze.analyze()");
                            BufferAnalyze.analyze();

                            Log.d("IOT","MOD_NAME:"+BufferAnalyze.MOD_NAME);
                            Log.d("IOT","Device_ID:"+BufferAnalyze.Device_ID);
                            Log.d("IOT","FW_Version:"+BufferAnalyze.FW_Version);
                            Log.d("IOT","IMEI:"+BufferAnalyze.IMEI);
                            Log.d("IOT","uuid:"+Helper.convertHexByteArrayToString(myTag.getUid()).toUpperCase());
                            Log.d("IOT","Number_of_Digital_Input:"+BufferAnalyze.Number_of_Digital_Input);
                            Log.d("IOT","Number_of_Digital_Output:"+BufferAnalyze.Number_of_Digital_Output);
                            Log.d("IOT","RS485:"+BufferAnalyze.RS485);
                            Log.d("IOT","_1_wire:"+BufferAnalyze._1_wire);
                            Log.d("IOT","RS232:"+BufferAnalyze.RS232);
                            Log.d("IOT","Network_Type:"+BufferAnalyze.Network_Type);
                            Log.d("IOT","Number_of_AI:"+BufferAnalyze.Number_of_AI);
                            Log.d("IOT","MQTTHost:"+BufferAnalyze.MQTTHost);
                            Log.d("IOT","MQTTClient:"+BufferAnalyze.MQTTClient);
                            Log.d("IOT","MQTTPwd:"+BufferAnalyze.MQTTPwd);
                            Log.d("IOT","MQTTTopic:"+BufferAnalyze.MQTTTopic);
                            Log.d("IOT","MQTTSub:"+BufferAnalyze.MQTTSub);
                            Log.d("IOT","MQTTPort:"+BufferAnalyze.MQTTPort);
                            Log.d("IOT","MQTTLive:"+BufferAnalyze.MQTTLive);
                            try {
                                Log.d("IOT", "Interrupt_Flag:" + BufferAnalyze.owInterrupt);
                            }
                            catch (Exception e){

                            }
                            Log.d("IOT","iTempInterv:"+BufferAnalyze.iTempInterv);
                            Log.d("IOT","OWInterv:"+BufferAnalyze.OWInterv);
                            Log.d("IOT","CTInterv:"+BufferAnalyze.CTInterv);
                            Log.d("IOT","InputInterv:"+BufferAnalyze.InputInterv);
                            Log.d("IOT","MDBInterv:"+BufferAnalyze.MDBInterv);
                            Log.d("IOT","GPSInterv:"+BufferAnalyze.GPSInterv);
                            Log.d("IOT","SSL:"+BufferAnalyze.option2.get(BufferAnalyze.SSL));
                            Log.d("IOT","SNI:"+BufferAnalyze.option2.get(BufferAnalyze.SNI));
                            Log.d("IOT","CA_Certification:"+BufferAnalyze.option2.get(BufferAnalyze.CA_Certification));
                            Log.d("IOT","ClientKey_Cert:"+BufferAnalyze.option2.get(BufferAnalyze.ClientKey_Cert));
                            Log.d("IOT","UserKey_Cert:"+BufferAnalyze.option2.get(BufferAnalyze.UserKey_Cert));
                            Log.d("IOT","RTC:"+BufferAnalyze.option2.get(BufferAnalyze.RTC));
                            Log.d("IOT","MQTTQos:"+BufferAnalyze.MQTTQos);
                            Log.d("IOT","MQTTRetain:"+BufferAnalyze.MQTTRetain);


                        }
                        if (nbrOfBytesRead != mNumberOfBytes) {
                            //Toast.makeText(this,getResources().getString(R.string.error_during_read_operation),Toast.LENGTH_LONG).show();
                        }



                    }
                    else {
                        // An issue occured retrieving AreaId from Address
                        // Tag type not yet handled
                        //Toast.makeText(this,getResources().getString(R.string.error_during_read_operation),Toast.LENGTH_LONG).show();
                    }

                }
                else{

                    Log.d("IOT","BufferAnalyze.analyze()");
                    BufferAnalyze.analyze();

                }


            } catch (STException e) {
                switch (e.getError()) {
                    case TAG_NOT_IN_THE_FIELD:
                        //Toast.makeText(this,getResources().getString(R.string.tag_not_in_the_field),Toast.LENGTH_LONG).show();
                        break;
                    case PASSWORD_NEEDED:
                    case ISO15693_BLOCK_IS_LOCKED:
                    case ISO15693_BLOCK_PROTECTED:
                    case WRONG_SECURITY_STATUS:
                        //Toast.makeText(this,getResources().getString(R.string.area_protected_in_read),Toast.LENGTH_LONG).show();
                        break;
                    default:
                        //Toast.makeText(this,getResources().getString(R.string.Command_failed),Toast.LENGTH_LONG).show();
                }
                Log.e(TAG, e.getMessage());
            }

            return 0;
        }


        @Override
        protected void onPostExecute(Integer result) {

            Log.d("IOT","onPostExecute-0");
            if (result == 0) {
                Log.d("IOT","onPostExecute-1");
                if (mView != null) {

                    Log.d("IOT","BufferAnalyze.MOD_NAME:"+BufferAnalyze.MOD_NAME);
                    Log.d("IOT","BufferAnalyze.IMEI:"+BufferAnalyze.IMEI);

                    //NfcAdapter mNfcAdapter = NfcAdapter.getDefaultAdapter(mView.getContext());
                    //mNfcAdapter.disableForegroundDispatch(getActivity());
                    //mNfcAdapter.disableReaderMode(getActivity());
                    BufferAnalyze.is_edit1=true;


                    getActivity().runOnUiThread (new Thread(new Runnable() {
                        public void run() {
                            mMOD_NAME_View = (TextView) mView.findViewById(R.id.MOD_NAME);
                            deviceID = (TextView) mView.findViewById(R.id.deviceID);
                            mIMEIView = (TextView) mView.findViewById(R.id.mIMEI);
                            mFW_Version = (TextView) mView.findViewById(R.id.mFW_Version);
                            UUID = (TextView) mView.findViewById(R.id.UUID);
                            RS485 = (TextView) mView.findViewById(R.id.RS485);
                            Number_of_Digital_Input = (TextView) mView.findViewById(R.id.Number_of_Digital_Input);
                            Number_of_Digital_Output = (TextView) mView.findViewById(R.id.Number_of_Digital_Output);
                            RS485 = (TextView) mView.findViewById(R.id.RS485);
                            _1_wire = (TextView) mView.findViewById(R.id._1_wire);
                            RS232 = (TextView) mView.findViewById(R.id.RS232);
                            Network_Type = (TextView) mView.findViewById(R.id.Network_Type);
                            Number_of_AI = (TextView) mView.findViewById(R.id.Number_of_AI);
                            DI_Port_group_LinearLayout = (LinearLayout) mView.findViewById(R.id.DI_Port_group_LinearLayout);
                            DO_Port_group_LinearLayout = (LinearLayout) mView.findViewById(R.id.DO_Port_group_LinearLayout);
                            network_group_LinearLayout = (LinearLayout) mView.findViewById(R.id.network_group_LinearLayout);
                            MQTTHost = (TextView) mView.findViewById(R.id.MQTTHost);
                            MQTTClient = (TextView) mView.findViewById(R.id.MQTTClient);
                            MQTTPwd = (TextView) mView.findViewById(R.id.MQTTPwd);
                            MQTTTopic = (TextView) mView.findViewById(R.id.MQTTTopic);
                            MQTTSub = (TextView) mView.findViewById(R.id.MQTTSub);
                            MQTTVer = (TextView) mView.findViewById(R.id.MQTTVer);
                            MQTTPort = (TextView) mView.findViewById(R.id.MQTTPort);
                            MQTTLive = (TextView) mView.findViewById(R.id.MQTTLive);
                            Interrupt_Flag = (TextView) mView.findViewById(R.id.Interrupt_Flag);
                            iTempInterv = (TextView) mView.findViewById(R.id.iTempInterv);
                            OWInterv = (TextView) mView.findViewById(R.id.OWInterv);
                            CTInterv = (TextView) mView.findViewById(R.id.CTInterv);
                            //InputInterv = (TextView) mView.findViewById(R.id.InputInterv);
                            MDBInterv = (TextView) mView.findViewById(R.id.MDBInterv);
                            GPSInterv = (TextView) mView.findViewById(R.id.GPSInterv);
                            SSL = (TextView) mView.findViewById(R.id.SSL);
                            SNI = (TextView) mView.findViewById(R.id.SNI);
                            CA_Certification = (TextView) mView.findViewById(R.id.CA_Certification);
                            ClientKey_Cert = (TextView) mView.findViewById(R.id.ClientKey_Cert);
                            UserKey_Cert = (TextView) mView.findViewById(R.id.UserKey_Cert);
                            RTC = (TextView) mView.findViewById(R.id.RTC);
                            M1_Band = (TextView) mView.findViewById(R.id.M1_Band);
                            NB_Band = (TextView) mView.findViewById(R.id.NB_Band);
                            PDP_Type = (TextView) mView.findViewById(R.id.PDP_Type);
                            APN = (TextView) mView.findViewById(R.id.APN);
                            PDP_Config_Data = (TextView) mView.findViewById(R.id.PDP_Config_Data);
                            PDP_Config_Header = (TextView) mView.findViewById(R.id.PDP_Config_Header);
                            MQTTQos = (TextView) mView.findViewById(R.id.MQTTQos);
                            MQTTRetain = (TextView) mView.findViewById(R.id.MQTTRetain);
                            Roam_Flag = (TextView) mView.findViewById(R.id.Roam_Flag);
                            InputInterv = (TextView) mView.findViewById(R.id.InputInterv);

                            Roam_Flag.setText((BufferAnalyze.Roam_Flag==0)?"Disable":"Enable");

                            if(BufferAnalyze.MQTTQos<=0x02) {
                                MQTTQos.setText(BufferAnalyze.option8.get(BufferAnalyze.MQTTQos));
                            }
                            else{
                                MQTTQos.setText(BufferAnalyze.option8.get(0));
                            }

                            if(BufferAnalyze.MQTTRetain<=0x01) {
                                MQTTRetain.setText(BufferAnalyze.option9.get(BufferAnalyze.MQTTRetain));
                            }
                            else{
                                MQTTRetain.setText(BufferAnalyze.option9.get(0));
                            }

                            mMOD_NAME_View.setText(BufferAnalyze.MOD_NAME);
                            mIMEIView.setText(BufferAnalyze.IMEI);
                            mFW_Version.setText(BufferAnalyze.FW_Version);
                            deviceID.setText(BufferAnalyze.Device_ID);
                            Number_of_Digital_Input.setText(""+BufferAnalyze.Number_of_Digital_Input);
                            Number_of_Digital_Output.setText(""+BufferAnalyze.Number_of_Digital_Output);
                            RS485.setText(""+BufferAnalyze.RS485);
                            _1_wire.setText(""+BufferAnalyze._1_wire);
                            RS232.setText(""+BufferAnalyze.RS232);
                            Network_Type.setText(""+BufferAnalyze.Network_Type);
                            Number_of_AI.setText(""+BufferAnalyze.Number_of_AI);
                            MQTTHost.setText(""+BufferAnalyze.MQTTHost);
                            MQTTClient.setText(""+BufferAnalyze.MQTTClient);
                            MQTTPwd.setText(""+BufferAnalyze.MQTTPwd);
                            MQTTTopic.setText(""+BufferAnalyze.MQTTTopic);
                            MQTTSub.setText(""+BufferAnalyze.MQTTSub);
                            MQTTVer.setText(""+BufferAnalyze.MQTTVer);
                            MQTTPort.setText(""+BufferAnalyze.MQTTPort);
                            MQTTLive.setText(""+BufferAnalyze.MQTTLive);

                            try {
                                Interrupt_Flag.setText("" + BufferAnalyze.owInterrupt);
                            }
                            catch (Exception e){
                                Interrupt_Flag.setText("");
                            }

                            iTempInterv.setText(""+BufferAnalyze.iTempInterv+" seconds");
                            OWInterv.setText(""+BufferAnalyze.OWInterv+" seconds");
                            CTInterv.setText(""+BufferAnalyze.CTInterv+" seconds");
                            //InputInterv.setText(""+BufferAnalyze.InputInterv);
                            MDBInterv.setText(""+BufferAnalyze.MDBInterv+" seconds");
                            GPSInterv.setText(""+BufferAnalyze.GPSInterv+" seconds");
                            InputInterv.setText(""+BufferAnalyze.InputInterv+" seconds");
                            SSL.setText(""+BufferAnalyze.option2.get(BufferAnalyze.SSL));
                            SNI.setText(""+BufferAnalyze.option2.get(BufferAnalyze.SNI));
                            CA_Certification.setText(""+BufferAnalyze.option2.get(BufferAnalyze.CA_Certification));
                            ClientKey_Cert.setText(""+BufferAnalyze.option2.get(BufferAnalyze.ClientKey_Cert));
                            UserKey_Cert.setText(""+BufferAnalyze.option2.get(BufferAnalyze.UserKey_Cert));
                            RTC.setText(""+BufferAnalyze.option2.get(BufferAnalyze.RTC));

                            String str="";
                            for(int i=0;i<BufferAnalyze.LTE_M_option.size();i++){
                                if(BufferAnalyze.LTE_M_option.get(i).sel==true) {
                                    str +=BufferAnalyze.LTE_M_option.get(i).name+" ";
                                }
                            }
                            M1_Band.setText(str);


                            str="";
                            for(int i=0;i<BufferAnalyze.NBIOT_option.size();i++){
                                if(BufferAnalyze.NBIOT_option.get(i).sel==true) {
                                    str +=BufferAnalyze.NBIOT_option.get(i).name+" ";
                                }
                            }
                            NB_Band.setText(str);

                            PDP_Type.setText(BufferAnalyze.PDP_Type);
                            APN.setText(BufferAnalyze.APN);
                            PDP_Config_Data.setText(BufferAnalyze.PDP_Data_Compression);
                            PDP_Config_Header.setText(BufferAnalyze.PDP_Header_Compression);


                            int myNum = 0;
                            try {
                                myNum = Integer.parseInt(Number_of_Digital_Input.getText().toString());
                            } catch(NumberFormatException nfe) {
                                System.out.println("Could not parse " + nfe);
                            }
                            System.out.println("myNum " + myNum);
                            DI_Port_group_LinearLayout.removeAllViews();
                            for(int i=0;i<(myNum);i++){
                                LinearLayout ll = new LinearLayout(mView.getContext());
                                ll.setOrientation(LinearLayout.HORIZONTAL);
                                TextView t = new TextView(mView.getContext());
                                TextView v = new TextView(mView.getContext());
                                t.setText("DI Port -"+(i));
                                System.out.println("BufferAnalyze.DI_Port_group_LinearLayout[i]" + BufferAnalyze.DI_Port_group_LinearLayout[i]);
                                v.setText(""+BufferAnalyze.option1.get(BufferAnalyze.DI_Port_group_LinearLayout[i]));
                                t.setTypeface(t.getTypeface(), Typeface.BOLD);
                                //v.setTypeface(t.getTypeface(), Typeface.BOLD);
                                Space s = new Space(mView.getContext());
                                s.setLayoutParams(new LinearLayout.LayoutParams(20,LinearLayout.LayoutParams.WRAP_CONTENT));
                                ll.addView(t);
                                ll.addView(s);
                                ll.addView(v);
                                DI_Port_group_LinearLayout.addView(ll);
                            }

                            try {
                                myNum = Integer.parseInt(Number_of_Digital_Output.getText().toString());
                            } catch(NumberFormatException nfe) {
                                System.out.println("Could not parse " + nfe);
                            }
                            System.out.println("myNum " + myNum);
                            DO_Port_group_LinearLayout.removeAllViews();
                            for(int i=0;i<myNum;i++){
                                LinearLayout ll = new LinearLayout(mView.getContext());
                                ll.setOrientation(LinearLayout.HORIZONTAL);
                                TextView t = new TextView(mView.getContext());
                                TextView v = new TextView(mView.getContext());
                                t.setText("DO Port -"+(i+1));
                                v.setText(""+BufferAnalyze.option7.get(BufferAnalyze.DO_Port_group_LinearLayout[i]));
                                t.setTypeface(t.getTypeface(), Typeface.BOLD);
                                Space s = new Space(mView.getContext());
                                s.setLayoutParams(new LinearLayout.LayoutParams(20,LinearLayout.LayoutParams.WRAP_CONTENT));
                                ll.addView(t);
                                ll.addView(s);
                                ll.addView(v);
                                DO_Port_group_LinearLayout.addView(ll);
                            }



                            try {
                                if(is_next_jump==false) {
                                    UUID.setText(Helper.convertHexByteArrayToString(myTag.getUid()).toUpperCase());
                                }
                            } catch (NullPointerException e) {
                                e.printStackTrace();
                            } catch (STException e) {
                                e.printStackTrace();
                            }

                        }
                    }));

                }
            }
            return;

        }
    }

    @Override
    public void fillView() {
        new FillViewTask().execute(myTag);
    }
}
