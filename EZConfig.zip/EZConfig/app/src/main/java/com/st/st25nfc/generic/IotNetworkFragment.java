/*
  * @author STMicroelectronics MMY Application team
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under ST MIX_MYLIBERTY SOFTWARE LICENSE AGREEMENT (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/Mix_MyLiberty
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied,
  * AND SPECIFICALLY DISCLAIMING THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
*/

package com.st.st25nfc.generic;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.st.st25nfc.R;
import com.st.st25nfc.generic.util.BufferAnalyze;
import com.st.st25sdk.NFCTag;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

public class IotNetworkFragment extends STFragment {


    public static IotNetworkFragment newInstance(Context context) {
        IotNetworkFragment f = new IotNetworkFragment();
        /* If needed, pass some argument to the fragment
        Bundle args = new Bundle();
        args.putInt("index", index);
        f.setArguments(args);
        */

        // Set the title of this fragment
        //f.setTitle(context.getResources().getString(R.string.tag_info));
        f.setTitle("Network");

        return f;
    }

    public IotNetworkFragment() {
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.fragment_iot_network, container, false);
        mView = view;

        initView();
        return (View) view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private class FillViewTask extends STFragment.FillViewTask {

        Spinner PDP_Type_spinner;
        EditText APN_editText;
        LinearLayout checkbox_LTE_M_LinearLayout;
        LinearLayout checkbox_NBIOT_LinearLayout;
        Spinner PDP_Data_Compression;
        Spinner PDP_Header_Compression;
        Spinner Roam_Flag;

        public FillViewTask() {
        }

        @Override
        protected Integer doInBackground(NFCTag... param) {

            return 0;
        }


        @Override
        protected void onPostExecute(Integer result) {

            if (result == 0) {
                if (mView != null) {
                    getActivity().runOnUiThread (new Thread(new Runnable() {
                        public void run() {

                            Roam_Flag = (Spinner) mView.findViewById(R.id.Roam_Flag);
                            PDP_Header_Compression = (Spinner) mView.findViewById(R.id.PDP_Header_Compression);
                            PDP_Data_Compression = (Spinner) mView.findViewById(R.id.PDP_Data_Compression);
                            PDP_Type_spinner = (Spinner) mView.findViewById(R.id.PDP_Type_spinner);
                            APN_editText = (EditText) mView.findViewById(R.id.APN_editText);
                            checkbox_LTE_M_LinearLayout = (LinearLayout) mView.findViewById(R.id.checkbox_LTE_M_LinearLayout);
                            checkbox_NBIOT_LinearLayout = (LinearLayout) mView.findViewById(R.id.checkbox_NBIOT_LinearLayout);



                            checkbox_LTE_M_LinearLayout.removeAllViews();
                            checkbox_NBIOT_LinearLayout.removeAllViews();

                            for(int i=0;i<BufferAnalyze.LTE_M_option.size();i++){
                                CheckBox c = new CheckBox(mView.getContext());
                                c.setText(""+BufferAnalyze.LTE_M_option_edit.get(i).name);
                                c.setChecked(BufferAnalyze.LTE_M_option_edit.get(i).sel);
                                int finalI = i;
                                c.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                    @Override
                                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                        Log.d("onTextChanged","sel:"+BufferAnalyze.LTE_M_option_edit.get(finalI).sel);

                                        if(finalI==14){

                                            if (buttonView.isChecked()) {
                                                // checked
                                                BufferAnalyze.LTE_M_option_edit.get(finalI).sel=true;
                                                BufferAnalyze.LTE_M_edit = BufferAnalyze.LTE_M_value.get(finalI).longValue();
                                            }
                                            else
                                            {
                                                // not checked
                                                BufferAnalyze.LTE_M_option_edit.get(finalI).sel=false;
                                            }

                                        }
                                        else{

                                            if (buttonView.isChecked()) {
                                                // checked
                                                BufferAnalyze.LTE_M_option_edit.get(finalI).sel=true;
                                                BufferAnalyze.LTE_M_edit = (BufferAnalyze.LTE_M_edit | BufferAnalyze.LTE_M_value.get(finalI).longValue());
                                            }
                                            else
                                            {
                                                // not checked
                                                BufferAnalyze.LTE_M_option_edit.get(finalI).sel=false;
                                                BufferAnalyze.LTE_M_edit = (BufferAnalyze.LTE_M_edit & ~(BufferAnalyze.LTE_M_value.get(finalI).longValue()));
                                            }

                                        }




                                        byte[] b = ("0x"+Long.toHexString(BufferAnalyze.LTE_M_edit)).getBytes(StandardCharsets.US_ASCII);
                                        for(int i=425;i<=436;i++){
                                            BufferAnalyze.edit_mBuffer[i]=0;
                                        }
                                        for(int i=0;i<b.length;i++){
                                            BufferAnalyze.edit_mBuffer[425+i]=b[i];
                                        }

                                    }
                                });
                                checkbox_LTE_M_LinearLayout.addView(c);
                            }


                            for(int i=0;i<BufferAnalyze.NBIOT_option.size();i++){
                                CheckBox c = new CheckBox(mView.getContext());
                                c.setText(""+BufferAnalyze.NBIOT_option.get(i).name);
                                c.setChecked(BufferAnalyze.NBIOT_option.get(i).sel);
                                int finalI = i;
                                c.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                    @Override
                                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {


                                        if(finalI==13){

                                            if (buttonView.isChecked()) {
                                                // checked
                                                BufferAnalyze.NBIOT_option_edit.get(finalI).sel=true;
                                                BufferAnalyze.NBIOT_edit = BufferAnalyze.NBIOT_value.get(finalI).longValue();
                                            }
                                            else
                                            {
                                                // not checked
                                                BufferAnalyze.NBIOT_option_edit.get(finalI).sel=false;
                                            }

                                        }
                                        else{
                                            if (buttonView.isChecked()) {
                                                // checked
                                                BufferAnalyze.NBIOT_option_edit.get(finalI).sel=true;
                                                BufferAnalyze.NBIOT_edit = (BufferAnalyze.NBIOT_edit | BufferAnalyze.NBIOT_value.get(finalI).longValue());
                                            }
                                            else
                                            {
                                                // not checked
                                                BufferAnalyze.NBIOT_option_edit.get(finalI).sel=false;
                                                BufferAnalyze.NBIOT_edit = (BufferAnalyze.NBIOT_edit & ~(BufferAnalyze.NBIOT_value.get(finalI).longValue()));
                                            }
                                        }



                                        byte[] b = ("0x"+Long.toHexString(BufferAnalyze.NBIOT_edit)).getBytes(StandardCharsets.US_ASCII);
                                        for(int i=437;i<=446;i++){
                                            BufferAnalyze.edit_mBuffer[i]=0;
                                        }
                                        for(int i=0;i<b.length;i++){
                                            BufferAnalyze.edit_mBuffer[437+i]=b[i];
                                        }

                                    }
                                });
                                checkbox_NBIOT_LinearLayout.addView(c);
                            }

                            APN_editText.setText(BufferAnalyze.APN_edit);
                            APN_editText.addTextChangedListener(new TextWatcher() {

                                @Override
                                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                                    String s = cs.toString().trim();
                                    Log.d("onTextChanged","s"+s);
                                    byte[] b = s.getBytes(StandardCharsets.US_ASCII);
                                    Log.d("onTextChanged","b.length"+b.length);
                                    BufferAnalyze.APN_edit = new String(b, StandardCharsets.UTF_8);
                                    for(int i=453;i<=515;i++){
                                        BufferAnalyze.edit_mBuffer[453]=0;
                                    }
                                    for(int i=0;i<b.length;i++){
                                        BufferAnalyze.edit_mBuffer[453+i]=b[i];
                                    }
                                }

                                @Override
                                public void beforeTextChanged(CharSequence s, int arg1, int arg2, int arg3) {

                                }

                                @Override
                                public void afterTextChanged(Editable arg0) {

                                }

                            });


                            SpinAdapter2 adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.PDP_Type_option);//simple_spinner_item 版面配置是由平台提供
                            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            PDP_Type_spinner.setAdapter(adapter);
                            PDP_Type_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    Log.d("IOT","選擇:");
                                    BufferAnalyze.PDP_Type_edit = BufferAnalyze.PDP_Type_option.get(position);
                                    byte[] b = BufferAnalyze.PDP_Type_edit.getBytes(StandardCharsets.US_ASCII);
                                    for(int i=447;i<=452;i++){
                                        BufferAnalyze.edit_mBuffer[i]=0;
                                    }
                                    for(int i=0;i < b.length;i++){
                                        BufferAnalyze.edit_mBuffer[447+i]=b[i];
                                    }

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            int index=0;
                            for(int i=0;i<BufferAnalyze.PDP_Type_option.size();i++){
                                if(BufferAnalyze.PDP_Type_edit.equals(BufferAnalyze.PDP_Type_option.get(i))){
                                    index=i;
                                    break;
                                }
                            }
                            PDP_Type_spinner.setSelection(index);


                            SpinAdapter2 PDP_Header_Compression_adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option6);//simple_spinner_item 版面配置是由平台提供
                            PDP_Header_Compression_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            PDP_Header_Compression.setAdapter(PDP_Header_Compression_adapter);
                            PDP_Header_Compression.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    Log.d("IOT","選擇:");
                                    BufferAnalyze.PDP_Header_Compression_edit = ""+(byte)position;
                                    Log.d("IOT","BufferAnalyze.PDP_Data_Compression_edit:"+BufferAnalyze.PDP_Header_Compression_edit);
                                    BufferAnalyze.edit_mBuffer[517] = BufferAnalyze.PDP_Header_Compression_edit.getBytes(StandardCharsets.US_ASCII)[0];
                                    Log.d("IOT","BufferAnalyze.edit_mBuffer[516]:"+BufferAnalyze.edit_mBuffer[517]);


                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            try {
                                PDP_Header_Compression.setSelection(Integer.parseInt(BufferAnalyze.PDP_Header_Compression_edit));
                            }
                            catch (Exception e){
                                PDP_Header_Compression.setSelection(0);
                            }



                            SpinAdapter2 PDP_Data_Compression_adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option5);//simple_spinner_item 版面配置是由平台提供
                            PDP_Data_Compression_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            PDP_Data_Compression.setAdapter(PDP_Data_Compression_adapter);
                            PDP_Data_Compression.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    Log.d("IOT","選擇:");
                                    BufferAnalyze.PDP_Data_Compression_edit = ""+(byte)position;
                                    Log.d("IOT","BufferAnalyze.PDP_Data_Compression_edit:"+BufferAnalyze.PDP_Data_Compression_edit);
                                    BufferAnalyze.edit_mBuffer[516] = BufferAnalyze.PDP_Data_Compression_edit.getBytes(StandardCharsets.US_ASCII)[0];
                                    Log.d("IOT","BufferAnalyze.edit_mBuffer[516]:"+BufferAnalyze.edit_mBuffer[516]);

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            try {
                                PDP_Data_Compression.setSelection(Integer.parseInt(BufferAnalyze.PDP_Data_Compression_edit));
                            }
                            catch (Exception e){
                                PDP_Data_Compression.setSelection(0);
                            }


                            SpinAdapter2 Roam_Flag_adapter = new SpinAdapter2(mView.getContext(), android.R.layout.simple_spinner_item,BufferAnalyze.option2);
                            Roam_Flag_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            Roam_Flag.setAdapter(Roam_Flag_adapter);
                            Roam_Flag.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    Log.d("IOT","選擇:"+(byte)position);
                                    BufferAnalyze.Roam_Flag_edit = (byte)position;
                                    BufferAnalyze.edit_mBuffer[518] = (byte)position;

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            Roam_Flag.setSelection(BufferAnalyze.Roam_Flag_edit);



                        }
                    }));
                }


            }
            return;

        }
    }

    @Override
    public void fillView() {
        new FillViewTask().execute(myTag);
    }
}
