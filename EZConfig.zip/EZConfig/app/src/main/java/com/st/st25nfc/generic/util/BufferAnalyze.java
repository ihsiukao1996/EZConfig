/*
  * @author STMicroelectronics MMY Application team
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under ST MIX_MYLIBERTY SOFTWARE LICENSE AGREEMENT (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/Mix_MyLiberty
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied,
  * AND SPECIFICALLY DISCLAIMING THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
*/

package com.st.st25nfc.generic.util;


import android.net.Uri;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import com.st.st25nfc.generic.STFragment;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class BufferAnalyze {

    public static byte voyagerReadPass[] = {(byte)0xDB, (byte)0xD9, (byte)0x87, (byte)0xE3, (byte)0x47, (byte)0x39, (byte)0xEF, (byte)0x2C, (byte)0xB3, (byte)0xCD, (byte)0x37, (byte)0xC5, (byte)0x29, (byte)0x37, (byte)0x19, (byte)0xD6};
    public static byte voyagerWritePass[] = {(byte)0x77, (byte)0xEA, (byte)0xE8, (byte)0xC0, (byte)0x01, (byte)0x5F, (byte)0xCA, (byte)0x4D, (byte)0xB3, (byte)0x6D, (byte)0x3E, (byte)0x3D, (byte)0x22, (byte)0x0A, (byte)0xFA, (byte)0x84};

    public static STFragment fragment1;
    public static STFragment fragment2;
    public static STFragment fragment3;
    public static STFragment fragment4;
    public static STFragment fragment5;

    public static boolean is_edit1 = false;

    public static byte resetFlag = 1;
    public static byte battery_ShutDown_Flag = 0;
    public static byte Roam_Flag = 0;
    public static byte Roam_Flag_edit = 0;

    //暫時保存位置9的MOD_NAME資訊以及位置44的Device_ID資訊
    public static String Device_ID="";
    public static String MOD_NAME="";

    static final String TAG = "BufferAnalyze";
    public static byte mBuffer[] = null;
    public static byte mBuffer2[] = null;

    public static byte edit_mBuffer[] = null;

    public static String PDP_Data_Compression="";
    public static String PDP_Data_Compression_edit="";
    public static String PDP_Header_Compression="";
    public static String PDP_Header_Compression_edit="";


    public static String IMEI;
    public static String FW_Version;
    public static String Device_Serinal_Number;
    public static String Number_of_AI;
    public static String Number_of_Digital_Input;
    public static String Number_of_Digital_Output;
    public static String RS485="";
    public static String _1_wire="";
    public static String RS232="";
    public static String Network_Type="";
    public static byte DI_Port_group_LinearLayout[] = new byte[16];
    public static byte DO_Port_group_LinearLayout[] = new byte[16];
    public static byte DI_Port_group_LinearLayout_edit[] = new byte[16];
    public static byte DO_Port_group_LinearLayout_edit[] = new byte[16];

    public static String MQTTHost="";
    public static String MQTTHost_edit="";

    public static String MQTTClient="";
    public static String MQTTClient_edit="";

    public static String MQTTPwd="";
    public static String MQTTPwd_edit="";

    public static String MQTTTopic="";
    public static String MQTTTopic_edit="";

    public static String MQTTSub="";
    public static String MQTTSub_edit="";

    public static String MQTTVer="";
    public static String MQTTVer_edit="";

    public static String MQTTPort="";
    public static String MQTTPort_edit="";

    public static String MQTTLive="";
    public static String MQTTLive_edit="";

    //public static byte Interrupt_Flag=0;
    //public static byte Interrupt_Flag_edit=0;

    public static int owInterrupt=0;
    public static int owInterrupt_edit=0;

    public static int inputInterrupt=0;
    public static int inputInterrupt_edit=0;

    public static int ctInterrupt=0;
    public static int ctInterrupt_edit=0;

    public static int acInterrupt=0;
    public static int acInterrupt_edit=0;

    public static String iTempInterv="";
    public static String iTempInterv_edit="";

    public static String OWInterv="";
    public static String OWInterv_edit="";

    public static String CTInterv="";
    public static String CTInterv_edit="";

    public static String InputInterv="";
    public static String InputInterv_edit="";

    public static String MDBInterv="";
    public static String MDBInterv_edit="";

    public static String GPSInterv="";
    public static String GPSInterv_edit="";

    public static int SSL=0;
    public static int SSL_edit=0;

    public static int SNI=0;
    public static int SNI_edit=0;

    public static int CA_Certification=0;
    public static int CA_Certification_edit=0;

    public static int ClientKey_Cert=0;
    public static int ClientKey_Cert_edit=0;

    public static int UserKey_Cert=0;
    public static int UserKey_Cert_edit=0;

    public static int RTC=0;
    public static int NU_OW=0;
    public static int NU_OW_edit=0;

    public static List<MDB_R> MDB_Rx_group = new ArrayList<>();
    public static List<MDB_R> MDB_Rx_group_edit = new ArrayList<>();

    public static String PDP_Type="";
    public static String PDP_Type_edit="";

    public static String APN="";
    public static String APN_edit="";

    public static long LTE_M=0;
    public static long LTE_M_edit=0;

    public static long NBIOT=0;
    public static long NBIOT_edit=0;

    public static String SSL_Version="";
    public static String SSL_Version_edit="";

    public static String Security_Level="";
    public static String Security_Level_edit="";

    public static Uri ca_fileUri;
    public static byte[] ca_mBuffer;

    public static Uri ClienCert_fileUri;
    public static byte[] ClienCert_mBuffer;

    public static Uri UserKey_Cert_fileUri;
    public static byte[] UserKey_Cert_mBuffer;

    public static byte MQTTQos;
    public static byte MQTTQos_edit;

    public static byte MQTTRetain;
    public static byte MQTTRetain_edit;

    public static List<String> option1 = Arrays.asList("Disable","Counter Mode","Normal Input");
    public static List<String> option2 = Arrays.asList("Disable", "Enable");
    public static List<String> option3 = Arrays.asList("Disable", "1","2","3","4");
    public static List<String> option4 = Arrays.asList("0x03","0x04");
    public static List<String> option5 = Arrays.asList("0","1","2","3");
    public static List<String> option6 = Arrays.asList("0","1","2","3","4");
    public static List<String> option7 = Arrays.asList("Logic High/Low");
    public static List<String> option8 = Arrays.asList("0:At most Once","1:At Least Once","2:Exactly Once");
    public static List<String> option9 = Arrays.asList("Not Retain","Retain");
    public static List<String> option10 = Arrays.asList("SSL3.0","TLS1.0","TLS1.1","TLS1.2","ALL");
    public static List<String> option11 = Arrays.asList("No Auth","Server Auth","Server & Client Auth");

    public static List<String> Protocol_option = Arrays.asList("LTE-M","NBIOT");
    public static List<String> PDP_Type_option = Arrays.asList("IP","PPP","IPV6","IPV4V6");

    public static List<LTE_M> LTE_M_option = new ArrayList<>();
    public static List<LTE_M> LTE_M_option_edit = new ArrayList<>();

    public static List<NBIOT> NBIOT_option = new ArrayList<>();
    public static List<NBIOT> NBIOT_option_edit = new ArrayList<>();

    public static List<String> LTE_M_name = Arrays.asList("LTE B1","LTE B2","LTE B3","LTE B4","LTE B5","LTE B8","LTE B12","LTE B13","LTE B18","LTE B19","LTE B20","LTE B26","LTE B28","LTE B39","Any frequency band");
    public static List<Number> LTE_M_value = Arrays.asList(
            0x1,
            0x2,
            0x4,
            0x8,
            0x10,
            0x80,
            0x800,
            0x1000,
            0x20000,
            0x40000,
            0x80000,
            0x2000000,
            0x8000000,
            0x4000000000L,
            0x400A0E189FL);

    public static List<String> NBIOT_name = Arrays.asList("LTE B1","LTE B2","LTE B3","LTE B4","LTE B5","LTE B8","LTE B12","LTE B13","LTE B18","LTE B19","LTE B20","LTE B26","LTE B28","Any frequency band");
    public static List<Number> NBIOT_value = Arrays.asList(
            0x1,
            0x2,
            0x4,
            0x8,
            0x10,
            0x80,
            0x800,
            0x1000,
            0x20000,
            0x40000,
            0x80000,
            0x2000000,
            0x8000000,
            0xA0E189F);


    public static void analyze(){


        Roam_Flag = mBuffer[518];
        Roam_Flag_edit = Roam_Flag;

        MQTTQos = mBuffer[934];
        MQTTQos_edit = MQTTQos;

        MQTTRetain = mBuffer[935];
        MQTTRetain_edit = MQTTRetain;

        PDP_Type="";
        mBuffer2 = new byte[6];
        for(int i=447;i<=452;i++){
            mBuffer2[i-447]=mBuffer[i];
        }
        PDP_Type = new String(mBuffer2, StandardCharsets.UTF_8);
        PDP_Type = PDP_Type.replaceAll("\0","");
        PDP_Type_edit = PDP_Type;



        SSL_Version="";
        mBuffer2 = new byte[1];
        mBuffer2[0]=mBuffer[1195];
        SSL_Version = new String(mBuffer2, StandardCharsets.UTF_8);
        SSL_Version_edit = SSL_Version;

        Security_Level="";
        mBuffer2 = new byte[1];
        mBuffer2[0]=mBuffer[1196];
        Security_Level = new String(mBuffer2, StandardCharsets.UTF_8);
        Security_Level_edit = Security_Level;

        PDP_Data_Compression="";
        mBuffer2 = new byte[1];
        mBuffer2[0]=mBuffer[516];
        PDP_Data_Compression = new String(mBuffer2, StandardCharsets.UTF_8);
        System.out.println("mBuffer[516]="+mBuffer[516]);
        System.out.println("PDP_Data_Compression="+PDP_Data_Compression);
        PDP_Data_Compression_edit = PDP_Data_Compression;

        PDP_Header_Compression="";
        mBuffer2 = new byte[1];
        mBuffer2[0]=mBuffer[517];
        PDP_Header_Compression = new String(mBuffer2, StandardCharsets.UTF_8);
        System.out.println("mBuffer[517]="+mBuffer[517]);
        System.out.println("PDP_Header_Compression="+PDP_Header_Compression);
        PDP_Header_Compression_edit = PDP_Header_Compression;

        LTE_M=0;
        mBuffer2 = new byte[12];
        for(int i=425;i<=436;i++){
            mBuffer2[i-425]=mBuffer[i];
        }
        String LTE_M_str = new String(mBuffer2, StandardCharsets.UTF_8);//ByteBuffer.wrap(mBuffer2).getLong();
        System.out.println("LTE_M_str="+LTE_M_str);
        LTE_M_str = LTE_M_str.replaceAll("\0","");
        LTE_M_str = LTE_M_str.replaceAll("0x","");
        try {
            LTE_M = Long.parseLong(LTE_M_str, 16);
        }
        catch (Exception e){
            LTE_M=0;
        }
        System.out.println("LTE_M="+LTE_M);
        LTE_M_edit = LTE_M;

        NBIOT=0;
        mBuffer2 = new byte[10];
        for(int i=437;i<=446;i++){
            mBuffer2[i-437]=mBuffer[i];
        }
        //NBIOT = ByteBuffer.wrap(mBuffer2).getLong();
        String NBIOT_str = new String(mBuffer2, StandardCharsets.UTF_8);//ByteBuffer.wrap(mBuffer2).getLong();
        System.out.println("NBIOT_str="+NBIOT_str);
        NBIOT_str = NBIOT_str.replaceAll("\0","");
        NBIOT_str = NBIOT_str.replaceAll("0x","");
        try {
            NBIOT = Long.parseLong(NBIOT_str, 16);
        }
        catch(Exception e){
            NBIOT=0;
        }
        NBIOT_edit = NBIOT;


        LTE_M_option_edit.clear();
        LTE_M_option.clear();
        for(int i=0;i<15;i++) {
            LTE_M _LTE_M = new LTE_M();
            _LTE_M.name=LTE_M_name.get(i);
            _LTE_M.value=LTE_M_value.get(i).longValue();
            if((LTE_M & _LTE_M.value)==_LTE_M.value){
                _LTE_M.sel=true;
            }
            LTE_M_option.add(_LTE_M);
            LTE_M_option_edit.add(_LTE_M);
        }

        NBIOT_option.clear();
        NBIOT_option_edit.clear();
        for(int i=0;i<14;i++) {
            NBIOT _NBIOT = new NBIOT();
            _NBIOT.name=NBIOT_name.get(i);
            _NBIOT.value=NBIOT_value.get(i).longValue();
            if((NBIOT & _NBIOT.value)==_NBIOT.value){
                _NBIOT.sel=true;
            }
            NBIOT_option.add(_NBIOT);
            NBIOT_option_edit.add(_NBIOT);
        }



        /*
        "Device Model Name (String)
        0x0: Voyager XB
        0x1: Voyager XC
        0x2: Voyager XD
        0x3: Voyager XE"
         */
        mBuffer2 = new byte[2];
        for(int i=9;i<=10;i++){
            mBuffer2[i-9]=mBuffer[i];
        }
        String mod_name = new String(mBuffer2, StandardCharsets.UTF_8);
        MOD_NAME = mod_name.equals("00")?"XB":mod_name.equals("01")?"XC":mod_name.equals("02")?"XD":"XE";


        mBuffer2 = new byte[15];
        for(int i=29;i<=43;i++){
            mBuffer2[i-29]=mBuffer[i];
        }
        IMEI = new String(mBuffer2, StandardCharsets.UTF_8);

        mBuffer2 = new byte[12];
        for(int i=11;i<=22;i++){
            mBuffer2[i-11]=mBuffer[i];
        }
        FW_Version = new String(mBuffer2, StandardCharsets.UTF_8);

        mBuffer2 = new byte[16];
        for(int i=72;i<=87;i++){
            mBuffer2[i-72]=mBuffer[i];
        }
        Device_Serinal_Number = new String(mBuffer2, StandardCharsets.UTF_8);


        mBuffer2 = new byte[2];
        for(int i=59;i<=60;i++){
            mBuffer2[i-59]=mBuffer[i];
        }
        Number_of_Digital_Input = new String(mBuffer2, StandardCharsets.UTF_8);

        mBuffer2 = new byte[2];
        for(int i=61;i<=62;i++){
            mBuffer2[i-61]=mBuffer[i];
        }
        Number_of_Digital_Output = new String(mBuffer2, StandardCharsets.UTF_8);



        //B0~B8(63~71)
        mBuffer2 = new byte[2];
        for(int i=67;i<=68;i++){
            mBuffer2[i-67]=mBuffer[i];
        }
        RS485 = new String(mBuffer2, StandardCharsets.UTF_8);
        RS485 = RS485.replaceAll("\0","0");

        mBuffer2 = new byte[2];
        for(int i=65;i<=66;i++){
            mBuffer2[i-65]=mBuffer[i];
        }
        _1_wire = new String(mBuffer2, StandardCharsets.UTF_8);
        _1_wire = _1_wire.replaceAll("\0","0");


        mBuffer2 = new byte[1];
        mBuffer2[0]=mBuffer[69];
        RS232 = new String(mBuffer2, StandardCharsets.UTF_8);
        RS232 = RS232.replaceAll("\0","0");
        //RS232 = RS232.equals("0")?"NO":"YES";


        mBuffer2 = new byte[2];
        for(int i=70;i<=71;i++){
            mBuffer2[i-70]=mBuffer[i];
        }
        Number_of_AI = new String(mBuffer2, StandardCharsets.UTF_8);
        Number_of_AI = Number_of_AI.replaceAll("\0","0");


        Log.d("IOT","mBuffer[88]:"+mBuffer[88]);
        Log.d("IOT","mBuffer[89]:"+mBuffer[89]);
        Log.d("IOT","mBuffer[90]:"+mBuffer[90]);
        Log.d("IOT","mBuffer[91]:"+mBuffer[91]);
        int num = ((int)mBuffer[88]<<24) & 0xff000000;
        num |= ((int)mBuffer[89]<<16) & 0xffff0000;
        num |= ((int)mBuffer[90]<<8) & 0xffffff00;
        num |= (int)mBuffer[91];
        Log.d("IOT","num:"+num);
        Network_Type="";
        if((num & 0x80000000) == 0x80000000){
            Network_Type="LoRa";
        }
        if((num & 0x40000000) == 0x40000000){
            Network_Type+=" LoRaWan";
        }
        if((num & 0x20000000) == 0x20000000){
            Network_Type+=" BT";
        }
        if((num & 0x10000000) == 0x10000000){
            Network_Type+=" SIGFOX";
        }
        if((num & 0x08000000) == 0x08000000){
            Network_Type+=" WIFI";
        }
        if((num & 0x04000000) == 0x04000000){
            Network_Type+=" 4G";
        }
        if((num & 0x02000000) == 0x02000000){
            Network_Type+=" NB-IoT";
        }
        if((num & 0x01000000) == 0x01000000){
            Network_Type+=" Z-Wave";
        }
        if((num & 0x00800000) == 0x00800000){
            Network_Type+=" Zigbee";
        }
        if((num & 0x00400000) == 0x00400000){
            Network_Type+=" Thread";
        }

        DI_Port_group_LinearLayout[15] = (byte) ((mBuffer[297] & 0xC0)>>6);
        DI_Port_group_LinearLayout[14] = (byte) ((mBuffer[297] & 0x30)>>4);
        DI_Port_group_LinearLayout[13] = (byte) ((mBuffer[297] & 0x0c)>>2);
        DI_Port_group_LinearLayout[12] = (byte) (mBuffer[297] & 0x03);
        DI_Port_group_LinearLayout[11] = (byte) ((mBuffer[298] & 0xC0)>>6);
        DI_Port_group_LinearLayout[10] = (byte) ((mBuffer[298] & 0x30)>>4);
        DI_Port_group_LinearLayout[9] = (byte) ((mBuffer[298] & 0x0c)>>2);
        DI_Port_group_LinearLayout[8] = (byte) (mBuffer[298] & 0x03);
        DI_Port_group_LinearLayout[7] = (byte) ((mBuffer[299] & 0xC0)>>6);
        DI_Port_group_LinearLayout[6] = (byte) ((mBuffer[299] & 0x30)>>4);
        DI_Port_group_LinearLayout[5] = (byte) ((mBuffer[299] & 0x0c)>>2);
        DI_Port_group_LinearLayout[4] = (byte) (mBuffer[299] & 0x03);
        DI_Port_group_LinearLayout[3] = (byte) ((mBuffer[300] & 0xC0)>>6);
        DI_Port_group_LinearLayout[2] = (byte) ((mBuffer[300] & 0x30)>>4);
        DI_Port_group_LinearLayout[1] = (byte) ((mBuffer[300] & 0x0c)>>2);
        DI_Port_group_LinearLayout[0] = (byte) (mBuffer[300] & 0x03);


        DI_Port_group_LinearLayout_edit[15] = (byte) ((mBuffer[297] & 0xC0)>>6);
        DI_Port_group_LinearLayout_edit[14] = (byte) ((mBuffer[297] & 0x30)>>4);
        DI_Port_group_LinearLayout_edit[13] = (byte) ((mBuffer[297] & 0x0c)>>2);
        DI_Port_group_LinearLayout_edit[12] = (byte) (mBuffer[297] & 0x03);
        DI_Port_group_LinearLayout_edit[11] = (byte) ((mBuffer[298] & 0xC0)>>6);
        DI_Port_group_LinearLayout_edit[10] = (byte) ((mBuffer[298] & 0x30)>>4);
        DI_Port_group_LinearLayout_edit[9] = (byte) ((mBuffer[298] & 0x0c)>>2);
        DI_Port_group_LinearLayout_edit[8] = (byte) (mBuffer[298] & 0x03);
        DI_Port_group_LinearLayout_edit[7] = (byte) ((mBuffer[299] & 0xC0)>>6);
        DI_Port_group_LinearLayout_edit[6] = (byte) ((mBuffer[299] & 0x30)>>4);
        DI_Port_group_LinearLayout_edit[5] = (byte) ((mBuffer[299] & 0x0c)>>2);
        DI_Port_group_LinearLayout_edit[4] = (byte) (mBuffer[299] & 0x03);
        DI_Port_group_LinearLayout_edit[3] = (byte) ((mBuffer[300] & 0xC0)>>6);
        DI_Port_group_LinearLayout_edit[2] = (byte) ((mBuffer[300] & 0x30)>>4);
        DI_Port_group_LinearLayout_edit[1] = (byte) ((mBuffer[300] & 0x0c)>>2);
        DI_Port_group_LinearLayout_edit[0] = (byte) (mBuffer[300] & 0x03);


        DO_Port_group_LinearLayout[15] = (byte) ((mBuffer[305] & 0xC0)>>6);
        DO_Port_group_LinearLayout[14] = (byte) ((mBuffer[305] & 0x30)>>4);
        DO_Port_group_LinearLayout[13] = (byte) ((mBuffer[305] & 0x0c)>>2);
        DO_Port_group_LinearLayout[12] = (byte) (mBuffer[305] & 0x03);
        DO_Port_group_LinearLayout[11] = (byte) ((mBuffer[306] & 0xC0)>>6);
        DO_Port_group_LinearLayout[10] = (byte) ((mBuffer[306] & 0x30)>>4);
        DO_Port_group_LinearLayout[9] = (byte) ((mBuffer[306] & 0x0c)>>2);
        DO_Port_group_LinearLayout[8] = (byte) (mBuffer[306] & 0x03);
        DO_Port_group_LinearLayout[7] = (byte) ((mBuffer[307] & 0xC0)>>6);
        DO_Port_group_LinearLayout[6] = (byte) ((mBuffer[307] & 0x30)>>4);
        DO_Port_group_LinearLayout[5] = (byte) ((mBuffer[307] & 0x0c)>>2);
        DO_Port_group_LinearLayout[4] = (byte) (mBuffer[307] & 0x03);
        DO_Port_group_LinearLayout[3] = (byte) ((mBuffer[308] & 0xC0)>>6);
        DO_Port_group_LinearLayout[2] = (byte) ((mBuffer[308] & 0x30)>>4);
        DO_Port_group_LinearLayout[1] = (byte) ((mBuffer[308] & 0x0c)>>2);
        DO_Port_group_LinearLayout[0] = (byte) (mBuffer[308] & 0x03);

        DO_Port_group_LinearLayout_edit[15] = (byte) ((mBuffer[305] & 0xC0)>>6);
        DO_Port_group_LinearLayout_edit[14] = (byte) ((mBuffer[305] & 0x30)>>4);
        DO_Port_group_LinearLayout_edit[13] = (byte) ((mBuffer[305] & 0x0c)>>2);
        DO_Port_group_LinearLayout_edit[12] = (byte) (mBuffer[305] & 0x03);
        DO_Port_group_LinearLayout_edit[11] = (byte) ((mBuffer[306] & 0xC0)>>6);
        DO_Port_group_LinearLayout_edit[10] = (byte) ((mBuffer[306] & 0x30)>>4);
        DO_Port_group_LinearLayout_edit[9] = (byte) ((mBuffer[306] & 0x0c)>>2);
        DO_Port_group_LinearLayout_edit[8] = (byte) (mBuffer[306] & 0x03);
        DO_Port_group_LinearLayout_edit[7] = (byte) ((mBuffer[307] & 0xC0)>>6);
        DO_Port_group_LinearLayout_edit[6] = (byte) ((mBuffer[307] & 0x30)>>4);
        DO_Port_group_LinearLayout_edit[5] = (byte) ((mBuffer[307] & 0x0c)>>2);
        DO_Port_group_LinearLayout_edit[4] = (byte) (mBuffer[307] & 0x03);
        DO_Port_group_LinearLayout_edit[3] = (byte) ((mBuffer[308] & 0xC0)>>6);
        DO_Port_group_LinearLayout_edit[2] = (byte) ((mBuffer[308] & 0x30)>>4);
        DO_Port_group_LinearLayout_edit[1] = (byte) ((mBuffer[308] & 0x0c)>>2);
        DO_Port_group_LinearLayout_edit[0] = (byte) (mBuffer[308] & 0x03);


        mBuffer2 = new byte[100];
        for(int i=684;i<=783;i++){
            mBuffer2[i-684]=mBuffer[i];
        }
        MQTTHost = new String(mBuffer2, StandardCharsets.UTF_8);
        MQTTHost = MQTTHost.replaceAll("\0","");
        MQTTHost_edit = MQTTHost;


        mBuffer2 = new byte[25];
        for(int i=784;i<=808;i++){
            mBuffer2[i-784]=mBuffer[i];
        }
        MQTTClient = new String(mBuffer2, StandardCharsets.UTF_8);
        MQTTClient = MQTTClient.replaceAll("\0","");
        MQTTClient_edit = MQTTClient;


        mBuffer2 = new byte[45];
        for(int i=809;i<=853;i++){
            mBuffer2[i-809]=mBuffer[i];
        }
        MQTTPwd = new String(mBuffer2, StandardCharsets.UTF_8);
        MQTTPwd = MQTTPwd.replaceAll("\0","");
        MQTTPwd_edit = MQTTPwd;

        mBuffer2 = new byte[25];
        for(int i=854;i<=878;i++){
            mBuffer2[i-854]=mBuffer[i];
        }
        MQTTTopic = new String(mBuffer2, StandardCharsets.UTF_8);
        MQTTTopic = MQTTTopic.replaceAll("\0","");
        MQTTTopic_edit = MQTTTopic;


        mBuffer2 = new byte[45];
        for(int i=879;i<=923;i++){
            mBuffer2[i-879]=mBuffer[i];
        }
        MQTTSub = new String(mBuffer2, StandardCharsets.UTF_8);
        MQTTSub = MQTTSub.replaceAll("\0","");
        MQTTSub_edit = MQTTSub;


        mBuffer2 = new byte[1];
        for(int i=924;i<=924;i++){
            mBuffer2[i-924]=mBuffer[i];
        }
        MQTTVer = new String(mBuffer2, StandardCharsets.UTF_8);
        MQTTVer = MQTTVer.replaceAll("\0","");
        MQTTVer_edit = MQTTVer;


        mBuffer2 = new byte[5];
        for(int i=925;i<=929;i++){
            mBuffer2[i-925]=mBuffer[i];
        }
        MQTTPort = new String(mBuffer2, StandardCharsets.UTF_8);
        MQTTPort = MQTTPort.replaceAll("\0","");
        MQTTPort_edit = MQTTPort;



        mBuffer2 = new byte[4];
        for(int i=930;i<=933;i++){
            mBuffer2[i-930]=mBuffer[i];
        }
        MQTTLive = new String(mBuffer2, StandardCharsets.UTF_8);
        MQTTLive = MQTTLive.replaceAll("\0","");
        MQTTLive_edit = MQTTLive;

        /*
        if((int)mBuffer[936] == 1) {
            Interrupt_Flag = (byte)255;
        }
        else {
            Interrupt_Flag = mBuffer[936];
        }
        Interrupt_Flag_edit = Interrupt_Flag;
        */

        num = (int)mBuffer[936];
        if(num == 1) {
            num = 0xFF;
        }
        owInterrupt = ((num & 0x80)==0x80)?1:0;
        owInterrupt_edit = owInterrupt;

        ctInterrupt = ((num & 0x40)==0x40)?1:0;
        ctInterrupt_edit = ctInterrupt;

        acInterrupt = ((num & 0x20)==0x20)?1:0;
        acInterrupt_edit = acInterrupt;

        inputInterrupt = ((num & 0x10)==0x10)?1:0;
        inputInterrupt_edit = inputInterrupt;

        mBuffer2 = new byte[4];
        for(int i=937;i<=940;i++){
            mBuffer2[i-937]=mBuffer[i];
        }
        iTempInterv = new String(mBuffer2, StandardCharsets.UTF_8);
        iTempInterv = iTempInterv.replaceAll("\0", "");
        if(iTempInterv.length() == 0) {
            iTempInterv = "0";
        }
        iTempInterv_edit  = iTempInterv;


        mBuffer2 = new byte[4];
        for(int i=941;i<=944;i++){
            mBuffer2[i-941]=mBuffer[i];
        }
        OWInterv = new String(mBuffer2, StandardCharsets.UTF_8);
        OWInterv = OWInterv.replaceAll("\0", "");
        if(OWInterv.length() == 0) {
            OWInterv = "0";
        }
        OWInterv_edit = OWInterv;


        mBuffer2 = new byte[4];
        for(int i=945;i<=948;i++){
            mBuffer2[i-945]=mBuffer[i];
        }
        CTInterv = new String(mBuffer2, StandardCharsets.UTF_8);
        CTInterv = CTInterv.replaceAll("\0", "");
        if(CTInterv.length() == 0) {
            CTInterv = "0";
        }
        CTInterv_edit = CTInterv;


        mBuffer2 = new byte[4];
        for(int i=949;i<=952;i++){
            mBuffer2[i-949]=mBuffer[i];
        }
        InputInterv = new String(mBuffer2, StandardCharsets.UTF_8);
        InputInterv = InputInterv.replaceAll("\0", "");
        if(InputInterv.length() == 0) {
            InputInterv = "0";
        }
        InputInterv_edit = InputInterv;


        mBuffer2 = new byte[4];
        for(int i=953;i<=956;i++){
            mBuffer2[i-953]=mBuffer[i];
        }
        MDBInterv = new String(mBuffer2, StandardCharsets.UTF_8);
        MDBInterv = MDBInterv.replaceAll("\0", "");
        if(MDBInterv.length() == 0) {
            MDBInterv = "0";
        }
        MDBInterv_edit = MDBInterv;


        mBuffer2 = new byte[4];
        for(int i=957;i<=960;i++){
            mBuffer2[i-957]=mBuffer[i];
        }
        GPSInterv = new String(mBuffer2, StandardCharsets.UTF_8);
        GPSInterv = GPSInterv.replaceAll("\0", "");
        if(GPSInterv.length() == 0) {
            GPSInterv = "0";
        }
        GPSInterv_edit = GPSInterv;


        Log.d("IOT","mBuffer[1193]:"+mBuffer[1193]);
        Log.d("IOT","mBuffer[1194]:"+mBuffer[1194]);
        num = (((int)mBuffer[1193]<<8) & 0xff00) | (int)mBuffer[1194];
        SSL = ((num & 0x8000)==0x8000)?1:0;
        SSL_edit = SSL;
        SNI = ((num & 0x4000)==0x4000)?1:0;
        SNI_edit = SNI;
        CA_Certification = ((num & 0x2000)==0x2000)?1:0;
        CA_Certification_edit = CA_Certification;
        ClientKey_Cert = ((num & 0x1000)==0x1000)?1:0;
        ClientKey_Cert_edit = ClientKey_Cert;
        UserKey_Cert = ((num & 0x0800)==0x0800)?1:0;
        UserKey_Cert_edit = UserKey_Cert;
        RTC = ((num & 0x0400)==0x0400)?1:0;



        NU_OW = (((int)mBuffer[317]<<8) & 0xff00) | (int)mBuffer[318];
        Log.d("IOT","[317]"+mBuffer[317]);
        Log.d("IOT","[318]"+mBuffer[318]);
        Log.d("IOT","NU_OW:"+NU_OW);
        NU_OW_edit = NU_OW;


        mBuffer2 = new byte[15];
        for(int i=44;i<=58;i++){
            mBuffer2[i-44]=mBuffer[i];
        }
        Device_ID = new String(mBuffer2, StandardCharsets.UTF_8);


        MDB_Rx_group.clear();
        MDB_Rx_group_edit.clear();
        for(int i=0;i<20;i++){
            int diff = i*6;
            MDB_R mdb_r = new MDB_R();
            mdb_r.Slave_Address=mBuffer[7357+diff];
            mdb_r.Register_Address = (((mBuffer[7357+1+diff] & 0xFF) << 8 ) | ((mBuffer[7357+2+diff] & 0xFF) << 0));
            mdb_r.Function_Code=mBuffer[7357+3+diff];
            mdb_r.Number_of_Register = (((mBuffer[7357+4+diff] & 0xFF) << 8 ) | ((mBuffer[7357+5+diff] & 0xFF) << 0));//((int)mBuffer[7357+4+diff]*256)+mBuffer[7357+5+diff];
            MDB_Rx_group.add(mdb_r);
            MDB_Rx_group_edit.add(mdb_r);
            System.out.println("mdb_r.Register_Address"+mdb_r.Register_Address);
            System.out.println("mBuffer["+(7357+i)+"]="+mBuffer[7357+i]);
            System.out.println("mBuffer["+(7357+1+i)+"]="+mBuffer[7357+1+i]);
            System.out.println("mBuffer["+(7357+2+i)+"]="+mBuffer[7357+2+i]);
            System.out.println("mBuffer["+(7357+3+i)+"]="+mBuffer[7357+3+i]);
            System.out.println("mBuffer["+(7357+4+i)+"]="+mBuffer[7357+4+i]);
            System.out.println("mBuffer["+(7357+5+i)+"]="+mBuffer[7357+5+i]);
        }




        mBuffer2 = new byte[63];
        for(int i=453;i<=515;i++){
            mBuffer2[i-453]=mBuffer[i];
        }
        APN = new String(mBuffer2, StandardCharsets.UTF_8);
        APN = APN.replaceAll("\0","");
        APN_edit = APN;
        System.out.println("APN="+APN);



    }

    public static void load_CA_Cert_File_in_to_buffer(){
        //Start Address (NDEF Offset)-1326
        //End Address (NDEF Offset) -3325
        //length=2000 byte

        //String s = new String(BufferAnalyze.ca_mBuffer, StandardCharsets.UTF_8);
        //Log.d("IOT","s.length():"+s.length());
        //s = s.replaceAll("\n","");
        //byte[] b = s.getBytes(StandardCharsets.US_ASCII);
        //Log.d("IOT","b.length():"+b.length);
        //BufferAnalyze.ca_mBuffer = new byte[b.length];
        //BufferAnalyze.ca_mBuffer = Arrays.copyOf(b, b.length);
        BufferAnalyze.edit_mBuffer[1324] = (byte)(BufferAnalyze.ca_mBuffer.length/256);
        BufferAnalyze.edit_mBuffer[1325] = (byte)(BufferAnalyze.ca_mBuffer.length%256);
        System.arraycopy(BufferAnalyze.ca_mBuffer,
                0,
                BufferAnalyze.edit_mBuffer,
                1326,
                BufferAnalyze.ca_mBuffer.length);

    }

    public static void load_Client_Cert_File_in_to_buffer(){
        //Start Address (NDEF Offset)-1326
        //End Address (NDEF Offset) -3325
        //length=2000 byte

        //String s = new String(BufferAnalyze.ClienCert_mBuffer, StandardCharsets.UTF_8);
        //Log.d("IOT","s.length():"+s.length());
        //s = s.replaceAll("\n","");
        //byte[] b = s.getBytes(StandardCharsets.US_ASCII);
        //Log.d("IOT","b.length():"+b.length);
        //BufferAnalyze.ClienCert_mBuffer = new byte[b.length];
        //BufferAnalyze.ClienCert_mBuffer = Arrays.copyOf(b, b.length);

        BufferAnalyze.edit_mBuffer[3336] = (byte)(BufferAnalyze.ClienCert_mBuffer.length/256);
        BufferAnalyze.edit_mBuffer[3337] = (byte)(BufferAnalyze.ClienCert_mBuffer.length%256);
        System.arraycopy(BufferAnalyze.ClienCert_mBuffer,
                0,
                BufferAnalyze.edit_mBuffer,
                3338,
                BufferAnalyze.ClienCert_mBuffer.length);
    }

    public static void load_UserK_Cert_File_in_to_buffer(){
        //Start Address (NDEF Offset)-1326
        //End Address (NDEF Offset) -3325
        //length=2000 byte

        //String s = new String(BufferAnalyze.UserKey_Cert_mBuffer, StandardCharsets.UTF_8);
        //Log.d("IOT","s.length():"+s.length());
        //s = s.replaceAll("\n","");
        //byte[] b = s.getBytes(StandardCharsets.US_ASCII);
        //Log.d("IOT","b.length():"+b.length);
        //BufferAnalyze.UserKey_Cert_mBuffer = new byte[b.length];
        //BufferAnalyze.UserKey_Cert_mBuffer = Arrays.copyOf(b, b.length);

        BufferAnalyze.edit_mBuffer[5348] = (byte)(BufferAnalyze.UserKey_Cert_mBuffer.length/256);
        BufferAnalyze.edit_mBuffer[5349] = (byte)(BufferAnalyze.UserKey_Cert_mBuffer.length%256);
        System.arraycopy(BufferAnalyze.UserKey_Cert_mBuffer,
                0,
                BufferAnalyze.edit_mBuffer,
                5350,
                BufferAnalyze.UserKey_Cert_mBuffer.length);
    }

    public static class MDB_R{
        public byte Slave_Address=0;
        public int Register_Address=0;
        public byte Function_Code=0;
        public int Number_of_Register=0;
    }


    public static class LTE_M{
        public String name="";
        public long value=0;
        public boolean sel=false;
    }

    public static class NBIOT{
        public String name="";
        public long value=0;
        public boolean sel=false;
    }

}






