/*
  * @author STMicroelectronics MMY Application team
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2017 STMicroelectronics</center></h2>
  *
  * Licensed under ST MIX_MYLIBERTY SOFTWARE LICENSE AGREEMENT (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/Mix_MyLiberty
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied,
  * AND SPECIFICALLY DISCLAIMING THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
*/

package com.st.st25nfc.generic;

import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.st.st25nfc.R;
import com.st.st25nfc.generic.util.BufferAnalyze;
import com.st.st25nfc.generic.util.TagDiscovery;
import com.st.st25nfc.generic.util.UIHelper;
import com.st.st25sdk.Helper;
import com.st.st25sdk.MultiAreaInterface;
import com.st.st25sdk.NFCTag;
import com.st.st25sdk.STException;
import com.st.st25sdk.TagHelper;
import com.st.st25sdk.type4a.FileControlTlvType4;
import com.st.st25sdk.type4a.STType4Tag;
import com.st.st25sdk.type4a.Type4Tag;
import com.st.st25sdk.type5.st25dv.ST25DVTag;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;
import static com.st.st25nfc.generic.MainActivity.file_bin_target;
import static com.st.st25nfc.generic.MainActivity.is_next_jump;
import static com.st.st25nfc.generic.util.UIHelper.getFileName;
import static com.st.st25sdk.MultiAreaInterface.AREA1;

public class IotWriterFragment extends STFragment{

    Thread mThread;
    int mDestinationByteAddress;
    byte[] mBuffer;
    InputStream inputStream;

    public static IotWriterFragment newInstance(Context context) {
        IotWriterFragment f = new IotWriterFragment();
        /* If needed, pass some argument to the fragment
        Bundle args = new Bundle();
        args.putInt("index", index);
        f.setArguments(args);
        */

        // Set the title of this fragment
        //f.setTitle(context.getResources().getString(R.string.tag_info));
        f.setTitle("Writer");

        return f;
    }

    public IotWriterFragment() {
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.fragment_writer, container, false);
        mView = view;

        initView();
        return (View) view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }


    private class FillViewTask extends STFragment.FillViewTask {

        TextView mUidView;
        TextView mManufacturerNameView;
        TextView mTagNameView;
        TextView mTagDescriptionView;
        TextView mTagTypeView;
        TextView mTagSizeView;
        TextView mTechListView;

        String mManufacturerName;
        String mUid;
        String mTagName;
        String mTagDescription;
        String mTagType;
        String mTagSize;
        String mTechList;


        Button Write;
        CheckBox Battery_Shut_Down;
        CheckBox Software_Reset;
        Button save_config;


        public FillViewTask() {
        }

        @Override
        protected Integer doInBackground(NFCTag... param) {

            /*
            if (myTag != null) {
                try {
                    mTagName = myTag.getName();
                    mTagDescription = myTag.getDescription();
                    mTagType = myTag.getTypeDescription();
                    mManufacturerName = ": " + myTag.getManufacturerName();
                    mUid = ": " + Helper.convertHexByteArrayToString(myTag.getUid()).toUpperCase();
                    mTagSize = ": " + String.valueOf(myTag.getMemSizeInBytes()) + " bytes";
                    mTechList = ": " + TextUtils.join("\n ", myTag.getTechList());
                } catch (STException e) {
                    return -1;

                }
            }

             */

            return 0;
        }





        @Override
        protected void onPostExecute(Integer result) {



            if (result == 0) {
                if (mView != null) {

                    Write = (Button) mView.findViewById(R.id.Write);
                    Battery_Shut_Down = (CheckBox) mView.findViewById(R.id.Battery_Shut_Down);
                    Battery_Shut_Down.setChecked(false);
                    Software_Reset = (CheckBox) mView.findViewById(R.id.Software_Reset);
                    Software_Reset.setChecked(false);
                    save_config = (Button) mView.findViewById(R.id.save_config);

                    Write.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {



                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

                            // set title
                            alertDialogBuilder.setTitle(getString(R.string.confirmation_needed));

                            // set dialog message
                            alertDialogBuilder
                                    .setMessage("Do you want to write the tag's memory?")
                                    .setCancelable(true)

                                    .setPositiveButton("Write tag's memory",new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,int id) {
                                            dialog.cancel();

                                            if(BufferAnalyze.battery_ShutDown_Flag == 1) {
                                                BufferAnalyze.edit_mBuffer[265]=0x69;
                                                BufferAnalyze.edit_mBuffer[266]=0x69;
                                            }
                                            else if(BufferAnalyze.resetFlag == 1) {
                                                BufferAnalyze.edit_mBuffer[265]=0x15;
                                                BufferAnalyze.edit_mBuffer[266]=0x6f;
                                            }

                                            mThread = new Thread(new ContentView());

                                            try {
                                                mDestinationByteAddress = Helper.convertHexStringToInt("0000");
                                            } catch (STException e) {
                                                e.printStackTrace();
                                                return;
                                            }

                                            mThread.start();
                                        }
                                    })
                                    .setNegativeButton(getString(R.string.cancel),new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,int id) {
                                            BufferAnalyze.edit_mBuffer[265]=0x00;
                                            BufferAnalyze.edit_mBuffer[266]=0x00;
                                            dialog.cancel();
                                        }
                                    });

                            // create alert dialog
                            AlertDialog alertDialog = alertDialogBuilder.create();

                            // show it
                            alertDialog.show();
                            alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setAllCaps(false);
                            alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setAllCaps(false);



                        }
                    });
/*
                    Battery_Shut_Down.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            //若使用者按下Battery Shut Down按鈕，在位置265寫入0x69，在位置266寫入0x69
                            BufferAnalyze.edit_mBuffer[265]=0x69;
                            BufferAnalyze.edit_mBuffer[266]=0x69;
                            getActivity().runOnUiThread (new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext(),"Entered Battery Shut Down",Toast.LENGTH_SHORT).show();
                                    //mNfcAdapter.disableReaderMode(getActivity());
                                }
                            }));

                        }
                    });
 */
                    Battery_Shut_Down.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            // TODO Auto-generated method stub
                            if(isChecked==true){
                                BufferAnalyze.battery_ShutDown_Flag = 1;
                                getActivity().runOnUiThread (new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getContext(),"Checked Battery Shut Down",Toast.LENGTH_SHORT).show();
                                        //mNfcAdapter.disableReaderMode(getActivity());
                                    }
                                }));
                            }
                            else{
                                BufferAnalyze.battery_ShutDown_Flag = 0;
                                BufferAnalyze.edit_mBuffer[265]=0x00;
                                BufferAnalyze.edit_mBuffer[266]=0x00;
                                getActivity().runOnUiThread (new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getContext(),"Unchecked Battery Shut Down",Toast.LENGTH_SHORT).show();
                                        //mNfcAdapter.disableReaderMode(getActivity());
                                    }
                                }));
                            }
                        }
                    });

/*
                    Software_Reset.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            //若使用者按下Software Rest按鈕，在位置265寫入0x15，在位置266寫入0x6F
                            BufferAnalyze.edit_mBuffer[265]=0x15;
                            BufferAnalyze.edit_mBuffer[266]=0x6f;

                            getActivity().runOnUiThread (new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getContext(),"Entered Software Reset",Toast.LENGTH_SHORT).show();
                                    //mNfcAdapter.disableReaderMode(getActivity());
                                }
                            }));

                        }
                    });
 */
                    Software_Reset.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            // TODO Auto-generated method stub
                            if(isChecked==true){
                                BufferAnalyze.resetFlag = 0;
                                BufferAnalyze.edit_mBuffer[265]=0x00;
                                BufferAnalyze.edit_mBuffer[266]=0x00;
                                getActivity().runOnUiThread (new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getContext(),"Will Not Reset",Toast.LENGTH_SHORT).show();
                                        //mNfcAdapter.disableReaderMode(getActivity());
                                    }
                                }));
                            }
                            else{
                                BufferAnalyze.resetFlag = 1;
                                getActivity().runOnUiThread (new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getContext(),"Will Reset",Toast.LENGTH_SHORT).show();
                                        //mNfcAdapter.disableReaderMode(getActivity());
                                    }
                                }));
                            }
                        }
                    });


                    save_config.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {


                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

                            final EditText name_editText = new EditText(getActivity()); //final一個editText
                            name_editText.setHint("File Name");

                            alertDialogBuilder.setView(name_editText);

                            // set title
                            alertDialogBuilder.setTitle(getString(R.string.confirmation_needed));

                            // set dialog message
                            alertDialogBuilder
                                    .setMessage("Please Enter File Name")
                                    .setCancelable(true)

                                    .setPositiveButton("SAVE",new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,int id) {

                                            if(name_editText.getText().toString().isEmpty()){
                                                getActivity().runOnUiThread (new Thread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(getContext(),"Please Enter File Name",Toast.LENGTH_LONG).show();
                                                        //mNfcAdapter.disableReaderMode(getActivity());
                                                    }
                                                }));
                                                return;
                                            }

                                            dialog.cancel();

                                            SharedPreferences pref = getContext().getSharedPreferences("IOTEASIER", MODE_PRIVATE);
                                            String json = pref.getString("bin檔案", "");
                                            Gson gson = new Gson();
                                            Type type = new TypeToken<List<File_bin>>() {}.getType();
                                            MainActivity.file_bin_list = gson.fromJson(json, type);

                                            if(MainActivity.file_bin_list==null){
                                                MainActivity.file_bin_list = new ArrayList<>();
                                            }

                                            File_bin bin = new File_bin();
                                            bin.file_name = ""+name_editText.getText();
                                            bin.data = null;
                                            bin.mBuffer = BufferAnalyze.edit_mBuffer;
                                            MainActivity.file_bin_list.add(bin);

                                            json = gson.toJson(MainActivity.file_bin_list);
                                            pref.edit().putString("bin檔案", json).apply();

                                            getActivity().runOnUiThread (new Thread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    Toast.makeText(getContext(),"Save success",Toast.LENGTH_LONG).show();
                                                    MainActivity.spinner.setAdapter(MainActivity.spinner_adapter);
                                                    MainActivity.spinner_adapter.notifyDataSetChanged();
                                                    //mNfcAdapter.disableReaderMode(getActivity());
                                                }
                                            }));

                                        }
                                    })
                                    .setNegativeButton(getString(R.string.cancel),new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,int id) {
                                            dialog.cancel();
                                        }
                                    });

                            // create alert dialog
                            AlertDialog alertDialog = alertDialogBuilder.create();

                            // show it
                            alertDialog.show();



                        }
                    });



                }

            }
            return;

        }
    }

    class ContentView implements Runnable, TagDiscovery.onTagDiscoveryCompletedListener {

        private int getMemoryAreaSizeInBytes(Type4Tag myTag, int area) {
            int memoryAreaSizeInBytes = 0;
            try {
                if (myTag instanceof STType4Tag) {

                    int fileId = UIHelper.getType4FileIdFromArea(area);
                    FileControlTlvType4 controlTlv = ((STType4Tag) myTag).getCCFileTlv(fileId);

                    memoryAreaSizeInBytes = controlTlv.getMaxFileSize();

                }  else {
                    if (myTag instanceof MultiAreaInterface) {
                        memoryAreaSizeInBytes = ((MultiAreaInterface) myTag).getAreaSizeInBytes(area);
                    } else {
                        memoryAreaSizeInBytes = myTag.getMemSizeInBytes();
                    }
                }
            } catch (STException e) {
                e.printStackTrace();
            }
            return memoryAreaSizeInBytes;
        }

        public void run() {
            byte buffer[] = null;
            boolean writingOk = false;
            //lv = (ListView) findViewById(R.id.writeBlockListView);


            int mNumberOfBytes;
            int mStartAddress;
            int  mArea = AREA1;

            int size = 8192;

            if(is_next_jump==true) {
                size = BufferAnalyze.edit_mBuffer.length;
            }
            else{

                size = getMemoryAreaSizeInBytes(((Type4Tag) myTag), mArea);
            }

            mNumberOfBytes = size;
            mStartAddress = 0;
            Log.d("IOT","mNumberOfBytes:"+mNumberOfBytes);

            int fileId = UIHelper.getType4FileIdFromArea(mArea);

            Log.d("IOT","fileId:"+fileId);

            UIHelper.displayCircularProgressBar(getActivity(), getString(R.string.please_wait));
            Intent nfcIntent = getActivity().getIntent();
            Tag androidTag = nfcIntent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            Log.d("IOT","androidTag:"+androidTag);
            if(androidTag!=null) {
                new TagDiscovery(this).execute(androidTag);
            }
            //Intent nfcIntent = getActivity().getIntent();
            //Tag androidTag = nfcIntent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            //new TagDiscovery(this).execute(androidTag);
            //NfcAdapter mNfcAdapter;
            //mNfcAdapter = NfcAdapter.getDefaultAdapter(getActivity());
            //PendingIntent mPendingIntent = PendingIntent.getActivity(getContext(), 0, new Intent(getActivity(), getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
            //mNfcAdapter.disableReaderMode(getActivity());
            //mNfcAdapter.enableReaderMode(getActivity(),null,0,null);
            //mNfcAdapter.enableForegroundDispatch(getActivity(), mPendingIntent, null /*nfcFiltersArray*/, null /*nfcTechLists*/);

            try {
                Thread.sleep(7000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


            try {

                if(myTag==null){
                    getActivity().runOnUiThread (new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getContext(),"請確認tag是否存在",Toast.LENGTH_LONG).show();
                            UIHelper.dismissCircularProgressBar();
                        }
                    }));
                    return;
                }

                //byte _mBuffer[] = ((Type4Tag) myTag).readBytes(fileId, 0, size);
                byte _mBuffer[] = null;

                if(((STType4Tag) myTag).isReadPasswordRequested(fileId)) {
                    _mBuffer = ((STType4Tag) myTag).readBytes(fileId, 0, size, BufferAnalyze.voyagerReadPass);
                }
                else {
                    _mBuffer = ((Type4Tag) myTag).readBytes(fileId, 0, size);
                }

                byte[] _bb = new byte[2];
                for(int i=9;i<=10;i++){
                    _bb[i-9]=_mBuffer[i];
                }
                String mod_name = new String(_bb, StandardCharsets.UTF_8);
                String _now_MOD_NAME = mod_name.equals("00")?"XB":mod_name.equals("01")?"XC":mod_name.equals("02")?"XD":"XE";
                Log.d("IOT","檢查MOD_NAME是否一致 => "+ _now_MOD_NAME +","+BufferAnalyze.MOD_NAME);


                if(!_now_MOD_NAME.equals(BufferAnalyze.MOD_NAME)){
                    UIHelper.dismissCircularProgressBar();
                    getActivity().runOnUiThread (new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getContext(),"Model Does Not Match. Writing Has Stopped",Toast.LENGTH_LONG).show();
                            //mNfcAdapter.disableReaderMode(getActivity());
                        }
                    }));

                    return;
                }



                _bb = new byte[15];
                for(int i=44;i<=58;i++){
                    _bb[i-44]=_mBuffer[i];
                }
                String _now_Device_ID = new String(_bb, StandardCharsets.UTF_8);
                Log.d("IOT","檢查Device_ID是否一致 => "+ _now_Device_ID+","+BufferAnalyze.Device_ID);

                if(!_now_Device_ID.equals(BufferAnalyze.Device_ID)){
                    UIHelper.dismissCircularProgressBar();

                    /*
                    getActivity().runOnUiThread (new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getContext(),"Model Does Not Match. Writing Has Stopped",Toast.LENGTH_LONG).show();
                            //mNfcAdapter.disableReaderMode(getActivity());
                        }
                    }));

                     */

                    getActivity().runOnUiThread (new Thread(new Runnable() {
                        @Override
                        public void run() {

                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

                            // set title
                            alertDialogBuilder.setTitle("Device ID Does Not Match");

                            // set dialog message
                            alertDialogBuilder
                                    .setMessage("Continue Writing?")
                                    .setCancelable(true)

                                    .setPositiveButton("yes",new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,int id) {
                                            dialog.cancel();



                                            mThread = new Thread(new ContentView2());

                                            try {
                                                mDestinationByteAddress = Helper.convertHexStringToInt("0000");
                                            } catch (STException e) {
                                                e.printStackTrace();
                                                return;
                                            }

                                            mThread.start();

                                        }
                                    })
                                    .setNegativeButton("no",new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,int id) {
                                            dialog.cancel();
                                        }
                                    });

                            // create alert dialog
                            AlertDialog alertDialog = alertDialogBuilder.create();

                            // show it
                            alertDialog.show();
                            alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setAllCaps(false);
                            alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setAllCaps(false);

                        }
                    }));


                    return;
                }


            } catch (STException e) {
                e.printStackTrace();
                UIHelper.dismissCircularProgressBar();
                getActivity().runOnUiThread (new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getContext(),""+e.getMessage(),Toast.LENGTH_LONG).show();
                        //mNfcAdapter.disableReaderMode(getActivity());
                    }
                }));

                return;
            }




            try {

                Log.d("onTextChanged","BufferAnalyze.edit_mBuffer[934]:"+BufferAnalyze.edit_mBuffer[934]);

                //UIHelper.displayCircularProgressBar(getActivity(), getString(R.string.please_wait));
                //myTag.writeBytes(mDestinationByteAddress, BufferAnalyze.edit_mBuffer);

                if(((STType4Tag) myTag).isWritePasswordRequested(fileId)) {
                    ((STType4Tag) myTag).writeBytes(fileId, mDestinationByteAddress, BufferAnalyze.edit_mBuffer, BufferAnalyze.voyagerWritePass);
                }
                else {
                    myTag.writeBytes(mDestinationByteAddress, BufferAnalyze.edit_mBuffer);
                }


                writingOk = true;
                // Re-read the data and display them
                //buffer = myTag.readBytes(mDestinationByteAddress, BufferAnalyze.edit_mBuffer.length);
                if(((STType4Tag) myTag).isReadPasswordRequested(fileId)) {
                    buffer = ((STType4Tag) myTag).readBytes(fileId, 0, size, BufferAnalyze.voyagerReadPass);
                }
                else {
                    buffer = ((Type4Tag) myTag).readBytes(fileId, 0, size);
                }
                // Warning: readBytes() may return less bytes than requested
                UIHelper.dismissCircularProgressBar();
                if (buffer != null && buffer.length != BufferAnalyze.edit_mBuffer.length) {
                    showToast(R.string.error_during_read_operation, buffer.length);
                }
                else{
                    showToast(R.string.write_successful, buffer.length);
                    getActivity().finish();
                }

            } catch (STException e) {
                UIHelper.dismissCircularProgressBar();
                if (e.getMessage() != null) {
                    Log.e(TAG, e.getMessage());
                } else {
                    Log.e(TAG, "Command failed");
                }
                if (!writingOk) {
                    showToast(R.string.error_while_writing_data, e.toString());
                } else {
                    showToast(R.string.error_while_reading_data, e.toString());
                }
            }


        }

        @Override
        public void onTagDiscoveryCompleted(NFCTag nfcTag, TagHelper.ProductID productId, STException e) {

            //MainActivity.setTag(nfcTag);
            myTag = nfcTag;
            Log.d("IOT","myTag:"+myTag);

        }
    }

    class ContentView2 implements Runnable, TagDiscovery.onTagDiscoveryCompletedListener {

        private int getMemoryAreaSizeInBytes(Type4Tag myTag, int area) {
            int memoryAreaSizeInBytes = 0;
            try {
                if (myTag instanceof STType4Tag) {

                    int fileId = UIHelper.getType4FileIdFromArea(area);
                    FileControlTlvType4 controlTlv = ((STType4Tag) myTag).getCCFileTlv(fileId);

                    memoryAreaSizeInBytes = controlTlv.getMaxFileSize();

                }  else {
                    if (myTag instanceof MultiAreaInterface) {
                        memoryAreaSizeInBytes = ((MultiAreaInterface) myTag).getAreaSizeInBytes(area);
                    } else {
                        memoryAreaSizeInBytes = myTag.getMemSizeInBytes();
                    }
                }
            } catch (STException e) {
                e.printStackTrace();
            }
            return memoryAreaSizeInBytes;
        }

        public void run() {
            byte buffer[] = null;
            boolean writingOk = false;
            //lv = (ListView) findViewById(R.id.writeBlockListView);


            int mNumberOfBytes;
            int mStartAddress;
            int  mArea = AREA1;

            int size = 8192;

            if(is_next_jump==true) {
                size = BufferAnalyze.edit_mBuffer.length;
            }
            else{

                size = getMemoryAreaSizeInBytes(((Type4Tag) myTag), mArea);
            }

            mNumberOfBytes = size;
            mStartAddress = 0;
            Log.d("IOT","mNumberOfBytes:"+mNumberOfBytes);

            int fileId = UIHelper.getType4FileIdFromArea(mArea);

            Log.d("IOT","fileId:"+fileId);

            UIHelper.displayCircularProgressBar(getActivity(), getString(R.string.please_wait));
            Intent nfcIntent = getActivity().getIntent();
            Tag androidTag = nfcIntent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            Log.d("IOT","androidTag:"+androidTag);
            if(androidTag!=null) {
                new TagDiscovery(this).execute(androidTag);
            }
            //Intent nfcIntent = getActivity().getIntent();
            //Tag androidTag = nfcIntent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            //new TagDiscovery(this).execute(androidTag);
            //NfcAdapter mNfcAdapter;
            //mNfcAdapter = NfcAdapter.getDefaultAdapter(getActivity());
            //PendingIntent mPendingIntent = PendingIntent.getActivity(getContext(), 0, new Intent(getActivity(), getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
            //mNfcAdapter.disableReaderMode(getActivity());
            //mNfcAdapter.enableReaderMode(getActivity(),null,0,null);
            //mNfcAdapter.enableForegroundDispatch(getActivity(), mPendingIntent, null /*nfcFiltersArray*/, null /*nfcTechLists*/);

            try {
                Thread.sleep(7000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }



            try {

                Log.d("onTextChanged","BufferAnalyze.edit_mBuffer[934]:"+BufferAnalyze.edit_mBuffer[934]);

                //UIHelper.displayCircularProgressBar(getActivity(), getString(R.string.please_wait));
                //myTag.writeBytes(mDestinationByteAddress, BufferAnalyze.edit_mBuffer);

                if(((STType4Tag) myTag).isWritePasswordRequested(fileId)) {
                    ((STType4Tag) myTag).writeBytes(fileId, mDestinationByteAddress, BufferAnalyze.edit_mBuffer, BufferAnalyze.voyagerWritePass);
                }
                else {
                    myTag.writeBytes(mDestinationByteAddress, BufferAnalyze.edit_mBuffer);
                }


                writingOk = true;
                // Re-read the data and display them
                //buffer = myTag.readBytes(mDestinationByteAddress, BufferAnalyze.edit_mBuffer.length);
                if(((STType4Tag) myTag).isReadPasswordRequested(fileId)) {
                    buffer = ((STType4Tag) myTag).readBytes(fileId, 0, size, BufferAnalyze.voyagerReadPass);
                }
                else {
                    buffer = ((Type4Tag) myTag).readBytes(fileId, 0, size);
                }
                // Warning: readBytes() may return less bytes than requested
                UIHelper.dismissCircularProgressBar();
                if (buffer != null && buffer.length != BufferAnalyze.edit_mBuffer.length) {
                    showToast(R.string.error_during_read_operation, buffer.length);
                }
                else{
                    showToast(R.string.write_successful, buffer.length);
                    getActivity().finish();
                }

            } catch (STException e) {
                UIHelper.dismissCircularProgressBar();
                if (e.getMessage() != null) {
                    Log.e(TAG, e.getMessage());
                } else {
                    Log.e(TAG, "Command failed");
                }
                if (!writingOk) {
                    showToast(R.string.error_while_writing_data, e.toString());
                } else {
                    showToast(R.string.error_while_reading_data, e.toString());
                }
            }


        }

        @Override
        public void onTagDiscoveryCompleted(NFCTag nfcTag, TagHelper.ProductID productId, STException e) {

            //MainActivity.setTag(nfcTag);
            myTag = nfcTag;
            Log.d("IOT","myTag:"+myTag);

        }
    }

    @Override
    public void fillView() {
        new FillViewTask().execute(myTag);
    }
}
